<?php
session_start();
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

if(!isset($_SESSION["usuarioLogado"])) {
    echo json_encode(['error' => 'Não autorizado']);
    exit();
}

require_once '../config/db.php';

$method = $_SERVER['REQUEST_METHOD'];

switch($method) {
    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);
        
        try {
            $campos = [];
            $valores = [];
            
            if(isset($data['hostname'])) {
                $campos[] = "hostname = ?";
                $valores[] = $data['hostname'];
            }
            
            if(isset($data['descricao'])) {
                $campos[] = "descricao = ?";
                $valores[] = $data['descricao'];
            }
            
            if(isset($data['responsavel'])) {
                $campos[] = "responsavel = ?";
                $valores[] = $data['responsavel'];
            }
            
            if(isset($data['status'])) {
                $campos[] = "status = ?";
                $valores[] = $data['status'];
                if($data['status'] == 'em_uso' || $data['status'] == 'reservado') {
                    $campos[] = "reservado_em = NOW()";
                }
            }
            
            $valores[] = $data['id'];
            
            $sql = "UPDATE ips SET " . implode(", ", $campos) . " WHERE id = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($valores);
            
            echo json_encode(['success' => true]);
        } catch(Exception $e) {
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;
        
    default:
        echo json_encode(['error' => 'Método não suportado']);
        break;
}
?>