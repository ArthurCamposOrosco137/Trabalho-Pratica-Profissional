<?php session_start(); ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Política de Privacidade - IP Grid</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
            --primary: #667eea;
            --secondary: #764ba2;
            --bg-body: #f5f7fb;
            --text-primary: #333;
            --text-secondary: #666;
            --card-bg: white;
            --navbar-bg: white;
            --border-color: #eef2f7;
            --shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        body.dark {
            --bg-body: #0f172a;
            --text-primary: #e2e8f0;
            --text-secondary: #94a3b8;
            --card-bg: #1e293b;
            --navbar-bg: #0f172a;
            --border-color: #334155;
            --shadow: 0 2px 10px rgba(0,0,0,0.2);
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-body);
            color: var(--text-primary);
            transition: background 0.3s, color 0.3s;
            line-height: 1.6;
        }
        .navbar {
            background: var(--navbar-bg);
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
        }
        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .logo {
            font-size: 1.5rem;
            font-weight: bold;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .nav-links {
            display: flex;
            gap: 1.5rem;
            align-items: center;
        }
        .nav-links a {
            text-decoration: none;
            color: var(--text-secondary);
        }
        .dark-mode-btn {
            background: none;
            border: none;
            font-size: 1.3rem;
            cursor: pointer;
            color: var(--primary);
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            padding: 2rem;
            margin-top: 80px;
        }
        .card {
            background: var(--card-bg);
            border-radius: 16px;
            padding: 2rem;
            box-shadow: var(--shadow);
        }
        h1 { color: var(--primary); margin-bottom: 1rem; }
        h2 { margin-top: 1.5rem; margin-bottom: 0.5rem; font-size: 1.3rem; color: var(--primary); }
        p { margin-bottom: 1rem; }
        .footer {
            text-align: center;
            margin-top: 2rem;
            padding: 1rem;
            color: var(--text-secondary);
        }
        hr { margin: 1.5rem 0; border-color: var(--border-color); }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">🌐 IP GRID</div>
            <div class="nav-links">
                <a href="index.php">Início</a>
                <a href="dashboard.php">Dashboard</a>
                <button id="darkModeToggle" class="dark-mode-btn">🌙</button>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="card">
            <h1>🔒 Política de Privacidade – IP Grid</h1>
            <p><strong>Última atualização:</strong> <?php echo date('d/m/Y'); ?></p>

            <h2>1. Introdução</h2>
            <p>Esta Política de Privacidade tem como objetivo informar como o sistema IP Grid coleta, utiliza, armazena e protege os dados pessoais de seus usuários, em conformidade com a Lei nº 13.709/2018 (Lei Geral de Proteção de Dados – LGPD).</p>
            <p>Ao utilizar o sistema, o usuário declara estar ciente e de acordo com os termos aqui descritos.</p>

            <h2>2. Dados Coletados</h2>
            <p>O IP Grid pode coletar os seguintes dados:</p>
            <p><strong>2.1 Dados fornecidos pelo usuário:</strong></p>
            <p>- Nome de usuário (login)<br>- Informações inseridas no sistema (ex: descrições de redes, observações)</p>
            <p><strong>2.2 Dados coletados automaticamente:</strong></p>
            <p>- Endereço IP do usuário<br>- Data e hora de acesso<br>- Ações realizadas dentro do sistema (logs de atividade)</p>

            <h2>3. Finalidade do Tratamento dos Dados</h2>
            <p>Os dados coletados são utilizados para:</p>
            <p>- Autenticação e controle de acesso ao sistema<br>- Registro de atividades para auditoria e segurança<br>- Gerenciamento eficiente de redes e endereços IP<br>- Melhoria contínua da plataforma</p>

            <h2>4. Base Legal (LGPD)</h2>
            <p>O tratamento de dados no IP Grid é realizado com base nas seguintes hipóteses legais:</p>
            <p>- Execução de contrato (uso do sistema)<br>- Legítimo interesse (segurança e funcionamento da aplicação)<br>- Cumprimento de obrigação legal, quando aplicável</p>

            <h2>5. Compartilhamento de Dados</h2>
            <p>O IP Grid não compartilha dados pessoais com terceiros, exceto quando:</p>
            <p>- Exigido por lei ou autoridade competente<br>- Necessário para garantir a segurança do sistema</p>

            <h2>6. Armazenamento e Segurança</h2>
            <p>Os dados são armazenados em ambiente controlado e protegidos por medidas de segurança, incluindo:</p>
            <p>- Controle de acesso por autenticação<br>- Uso de tokens de segurança (ex: proteção contra CSRF)<br>- Registro de logs de atividade</p>
            <p>Apesar disso, nenhum sistema é completamente seguro, e o IP Grid não pode garantir segurança absoluta.</p>

            <h2>7. Direitos do Titular dos Dados</h2>
            <p>De acordo com a LGPD, o usuário tem direito a:</p>
            <p>- Confirmar a existência de tratamento de dados<br>- Acessar seus dados pessoais<br>- Corrigir dados incompletos ou incorretos<br>- Solicitar a exclusão de dados, quando aplicável<br>- Revogar o consentimento</p>
            <p>Solicitações podem ser feitas diretamente à equipe responsável pelo sistema.</p>

            <h2>8. Retenção de Dados</h2>
            <p>Os dados serão mantidos apenas pelo tempo necessário para cumprir as finalidades descritas nesta política, respeitando obrigações legais e necessidades do sistema.</p>

            <h2>9. Uso de Cookies</h2>
            <p>O sistema pode utilizar cookies ou sessões para manter o usuário autenticado e melhorar a experiência de navegação.</p>

            <h2>10. Alterações na Política</h2>
            <p>Esta Política de Privacidade pode ser alterada a qualquer momento, sendo recomendada a revisão periódica pelo usuário.</p>

            <h2>11. Natureza Acadêmica</h2>
            <p>O IP Grid é um projeto acadêmico, podendo não possuir todos os níveis de segurança e conformidade exigidos por sistemas comerciais.</p>

            <h2>12. Contato</h2>
            <p>Em caso de dúvidas sobre esta Política de Privacidade ou sobre o tratamento de dados, o usuário pode entrar em contato com os responsáveis pelo projeto.</p>

            <hr>
            <p style="text-align: center;">IP Grid © <?php echo date('Y'); ?> – Sistema de Gerenciamento Inteligente de IPs</p>
        </div>
        <div class="footer">
            <p><a href="termos.php">Termos de Uso</a> | <a href="index.php">Voltar ao início</a></p>
        </div>
    </div>

    <script>
        const toggle = document.getElementById('darkModeToggle');
        if (toggle) {
            const isDark = localStorage.getItem('darkMode') === 'true';
            if (isDark) { document.body.classList.add('dark'); toggle.textContent = '☀️'; }
            toggle.addEventListener('click', () => {
                document.body.classList.toggle('dark');
                const dark = document.body.classList.contains('dark');
                localStorage.setItem('darkMode', dark);
                toggle.textContent = dark ? '☀️' : '🌙';
            });
        }
    </script>
</body>
</html>