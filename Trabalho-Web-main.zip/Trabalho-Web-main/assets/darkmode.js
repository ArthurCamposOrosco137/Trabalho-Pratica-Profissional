// Dark mode toggle com persistência em localStorage
(function() {
    const toggleBtn = document.getElementById('darkModeToggle');
    if (!toggleBtn) return;

    const isDark = localStorage.getItem('darkMode') === 'true';
    if (isDark) {
        document.body.classList.add('dark');
        toggleBtn.textContent = '☀️';
    }

    toggleBtn.addEventListener('click', () => {
        document.body.classList.toggle('dark');
        const darkNow = document.body.classList.contains('dark');
        localStorage.setItem('darkMode', darkNow);
        toggleBtn.textContent = darkNow ? '☀️' : '🌙';
    });
})();