<?php
session_start();
$erro = isset($_GET['erro']) ? $_GET['erro'] : '';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IP Grid - Cadastro</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        :root {
            --primary-green: #4caf50;
            --primary-dark: #0f4f1f;
            --primary-light: #1f6a2c;
            --bg-gradient-light: linear-gradient(135deg, #6d82e0, #8a55c9);
            --card-bg: white;
            --text-primary: #333;
            --text-secondary: #666;
            --input-border: #d4d4d4;
            --input-bg: white;
            --shadow: 0 20px 35px rgba(0,0,0,0.1);
            --btn-hover: #43a047;
        }

        body.dark {
            --primary-green: #2e7d32;
            --primary-dark: #1b5e20;
            --primary-light: #2e7d32;
            --bg-gradient-light: #0f172a;
            --card-bg: #1e293b;
            --text-primary: #e2e8f0;
            --text-secondary: #94a3b8;
            --input-border: #475569;
            --input-bg: #1e293b;
            --shadow: 0 20px 35px rgba(0,0,0,0.3);
            --btn-hover: #1b5e20;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-gradient-light);
            color: var(--text-primary);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            max-width: 1000px;
            width: 100%;
            display: flex;
            background: var(--card-bg);
            border-radius: 20px;
            overflow: hidden;
            box-shadow: var(--shadow);
        }

        .login-box {
            width: 45%;
            background: #f3f3f3;
            padding: 50px 30px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        body.dark .login-box {
            background: var(--card-bg);
        }

        .login-box h2 {
            font-size: 26px;
            color: #222;
            margin-bottom: 25px;
            text-align: center;
        }
        body.dark .login-box h2 {
            color: var(--text-primary);
        }

        label {
            font-size: 14px;
            color: #555;
            margin-bottom: 5px;
            margin-top: 12px;
            display: block;
        }
        body.dark label {
            color: var(--text-secondary);
        }

        input {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid var(--input-border);
            border-radius: 8px;
            font-size: 14px;
            background: var(--input-bg);
            color: var(--text-primary);
            transition: 0.2s;
        }
        input:focus {
            border-color: var(--primary-green);
            outline: none;
        }

        button {
            margin-top: 12px;
            width: 100%;
            padding: 12px;
            background: var(--primary-green);
            border: none;
            border-radius: 8px;
            color: white;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.2s;
        }
        button:hover {
            background: var(--btn-hover);
            transform: translateY(-2px);
        }

        .cadastro-texto {
            text-align: center;
            margin-top: 20px;
            font-size: 13px;
            color: #777;
        }
        body.dark .cadastro-texto {
            color: var(--text-secondary);
        }
        .cadastro-texto a {
            color: var(--primary-green);
            text-decoration: none;
        }
        .cadastro-texto a:hover {
            text-decoration: underline;
        }

        /* Checkbox dos Termos */
        .termos-checkbox {
            margin: 10px 0 2px 0;
            display: flex;
            align-items: flex-start;
            gap: 8px;
        }
        .termos-checkbox input {
            width: 18px;
            height: 18px;
            margin-top: 2px;
        }
        .termos-checkbox label {
            font-size: 13px;
            margin: 0;
            line-height: 1.4;
            color: var(--text-secondary);
        }
        .termos-checkbox a {
            color: var(--primary-green);
            text-decoration: none;
        }
        .termos-checkbox a:hover {
            text-decoration: underline;
        }

        .info-box {
            width: 55%;
            padding: 50px 30px;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary-light));
            display: flex;
            flex-direction: column;
            justify-content: center;
            color: white;
        }
        .info-box h1 {
            text-align: center;
            font-size: 32px;
            letter-spacing: 2px;
            margin-bottom: 30px;
        }
        .info-card {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 12px;
            padding: 16px;
            margin-bottom: 16px;
        }
        .info-card h3 {
            font-size: 16px;
            margin-bottom: 6px;
        }
        .info-card p {
            font-size: 13px;
            line-height: 1.4;
            opacity: 0.9;
        }

        .dark-mode-btn {
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--card-bg);
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: var(--primary-green);
            width: 45px;
            height: 45px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: var(--shadow);
            transition: 0.2s;
            z-index: 1000;
        }
        .dark-mode-btn:hover {
            transform: scale(1.05);
        }

        .erro {
            background: #f8d7da;
            color: #721c24;
            padding: 8px 12px;
            border-radius: 8px;
            margin-bottom: 15px;
            text-align: center;
            font-size: 13px;
        }
        body.dark .erro {
            background: #641e24;
            color: #f9acaa;
        }

        @media (max-width: 800px) {
            .container {
                flex-direction: column;
                max-width: 500px;
            }
            .login-box, .info-box {
                width: 100%;
            }
            .login-box {
                padding: 40px 25px;
            }
        }
    </style>
</head>
<body>
    <button id="darkModeToggle" class="dark-mode-btn">🌙</button>

    <div class="container">
        <div class="login-box">
            <h2>Cadastro</h2>

            <?php if ($erro == 'usuario_existe'): ?>
                <div class="erro">Usuário já existe! Tente outro nome.</div>
            <?php elseif ($erro == 'termos'): ?>
                <div class="erro">Você precisa aceitar os Termos de Uso.</div>
            <?php elseif ($erro == 'campos_vazios'): ?>
                <div class="erro">Todos os campos são obrigatórios.</div>
            <?php elseif ($erro == 'email_invalido'): ?>
                <div class="erro">Digite um e-mail válido.</div>
            <?php elseif ($erro == 'banco'): ?>
                <div class="erro">Erro interno. Tente novamente.</div>
            <?php endif; ?>

            <form action="cadastrar.php" method="POST" onsubmit="return validarCadastro()">
                <label for="novoUsuario">Usuário</label>
                <input type="text" id="novoUsuario" name="usuario" placeholder="Crie seu usuário" required>

                <label for="email">E-mail</label>
                <input type="email" id="email" name="email" placeholder="Digite seu e-mail" required>

                <label for="novaSenha">Senha</label>
                <input type="password" id="novaSenha" name="senha" placeholder="Crie sua senha" required>

                <label for="confirmarSenha">Confirmar senha</label>
                <input type="password" id="confirmarSenha" placeholder="Confirme sua senha" required>

                <div class="termos-checkbox">
                    <input type="checkbox" id="aceito_termos" name="aceito_termos" required>
                    <label for="aceito_termos">
                        Li e aceito os <a href="../termos.php" target="_blank">Termos de Uso e Política de Privacidade</a>
                    </label>
                </div>

                <button type="submit">Cadastrar</button>
            </form>

            <p class="cadastro-texto">
                Já tem conta?
                <a href="login.php">Voltar para login</a>
            </p>
        </div>

        <div class="info-box">
            <h1>IP GRID</h1>
            <div class="info-card">
                <h3>Cadastro Rápido</h3>
                <p>Crie sua conta de forma simples e acesse o sistema.</p>
            </div>
            <div class="info-card">
                <h3>Mais Segurança</h3>
                <p>Organize os dados da rede com mais confiabilidade.</p>
            </div>
            <div class="info-card">
                <h3>Controle Total</h3>
                <p>Visualize melhor sua infraestrutura e evite erros.</p>
            </div>
            <div class="info-card">
                <h3>Experiência Moderna</h3>
                <p>Interface prática para facilitar o uso no dia a dia.</p>
            </div>
        </div>
    </div>

    <script>
        const darkModeToggle = document.getElementById('darkModeToggle');
        if (darkModeToggle) {
            const isDark = localStorage.getItem('darkMode') === 'true';
            if (isDark) {
                document.body.classList.add('dark');
                darkModeToggle.textContent = '☀️';
            }
            darkModeToggle.addEventListener('click', () => {
                document.body.classList.toggle('dark');
                const isDarkNow = document.body.classList.contains('dark');
                localStorage.setItem('darkMode', isDarkNow);
                darkModeToggle.textContent = isDarkNow ? '☀️' : '🌙';
            });
        }

        function validarCadastro() {
            const senha = document.getElementById('novaSenha').value;
            const confirmar = document.getElementById('confirmarSenha').value;
            const aceito = document.getElementById('aceito_termos').checked;

            if (senha !== confirmar) {
                alert('As senhas não coincidem!');
                return false;
            }
            if (!aceito) {
                alert('Você precisa aceitar os Termos de Uso e Política de Privacidade.');
                return false;
            }
            return true;
        }
    </script>
</body>
</html>