<?php
require_once "../config/db.php";

// Verificar se os termos foram aceitos
if (!isset($_POST['aceito_termos'])) {
    header("Location: cadastro.php?erro=termos");
    exit;
}

$usuario = trim($_POST["usuario"]);
$email   = trim($_POST["email"]);
$senha   = trim($_POST["senha"]);

$senhaHash = password_hash($senha, PASSWORD_DEFAULT);

try {
  $stmt = $pdo->prepare("INSERT INTO usuarios (usuario, email, senha) VALUES (?, ?, ?)");
  $stmt->execute([$usuario, $email, $senhaHash]);
  header("Location: login.php?cadastro=ok");
} catch (PDOException $e) {
  header("Location: cadastro.php?erro=usuario_existe");
}
exit;
?>