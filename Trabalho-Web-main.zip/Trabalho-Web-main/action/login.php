<?php
session_start();
$erro = isset($_GET['erro']) ? $_GET['erro'] : '';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IP Grid - Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* ========== VARIÁVEIS (VERDE) ========== */
        :root {
            --primary-green: #4caf50;
            --primary-dark: #0f4f1f;
            --primary-light: #1f6a2c;
            --bg-gradient-light: linear-gradient(135deg, #6d82e0, #8a55c9);
            --card-bg: white;
            --text-primary: #333;
            --text-secondary: #666;
            --input-border: #d4d4d4;
            --input-bg: white;
            --shadow: 0 20px 35px rgba(0,0,0,0.1);
            --btn-hover: #43a047;
        }

        body.dark {
            --primary-green: #2e7d32;
            --primary-dark: #1b5e20;
            --primary-light: #2e7d32;
            --bg-gradient-light: #0f172a;
            --card-bg: #1e293b;
            --text-primary: #e2e8f0;
            --text-secondary: #94a3b8;
            --input-border: #475569;
            --input-bg: #1e293b;
            --shadow: 0 20px 35px rgba(0,0,0,0.3);
            --btn-hover: #2b5e2f;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-gradient-light);
            color: var(--text-primary);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.3s, color 0.3s;
            padding: 20px;
        }

        .container {
            width: 900px;
            max-width: 100%;
            display: flex;
            background: var(--card-bg);
            border-radius: 20px;
            overflow: hidden;
            box-shadow: var(--shadow);
        }

        .login-box {
            width: 50%;
            background: #f3f3f3;
            padding: 70px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        body.dark .login-box {
            background: var(--card-bg);
        }

        .login-box h2 {
            font-size: 26px;
            color: #222;
            margin-bottom: 30px;
            text-align: center;
        }
        body.dark .login-box h2 {
            color: var(--text-primary);
        }

        label {
            font-size: 15px;
            color: #666;
            margin-bottom: 8px;
            margin-top: 10px;
            display: block;
        }
        body.dark label {
            color: var(--text-secondary);
        }

        input {
            width: 100%;
            padding: 14px;
            border: 1px solid var(--input-border);
            border-radius: 8px;
            outline: none;
            font-size: 14px;
            background: var(--input-bg);
            color: var(--text-primary);
        }
        input:focus {
            border-color: var(--primary-green);
        }

        button {
            margin-top: 25px;
            width: 100%;
            padding: 14px;
            background: var(--primary-green);
            border: none;
            border-radius: 8px;
            color: white;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }
        button:hover {
            background: var(--btn-hover);
            transform: translateY(-2px);
        }

        .cadastro-texto {
            text-align: center;
            margin-top: 18px;
            color: #777;
            font-size: 14px;
        }
        body.dark .cadastro-texto {
            color: var(--text-secondary);
        }
        .cadastro-texto a {
            color: var(--primary-green);
            text-decoration: none;
        }
        .cadastro-texto a:hover {
            text-decoration: underline;
        }

        .info-box {
            width: 50%;
            padding: 40px 25px;
            background: linear-gradient(135deg, var(--primary-dark), var(--primary-light));
            display: flex;
            flex-direction: column;
            justify-content: center;
            color: white;
        }
        .info-box h1 {
            text-align: center;
            font-size: 32px;
            letter-spacing: 2px;
            margin-bottom: 25px;
        }
        .info-card {
            background: rgba(255, 255, 255, 0.18);
            border-radius: 14px;
            padding: 18px 16px;
            margin-bottom: 16px;
        }
        .info-card h3 {
            font-size: 16px;
            margin-bottom: 8px;
        }
        .info-card p {
            font-size: 14px;
            line-height: 1.4;
            opacity: 0.9;
        }

        /* Dark mode toggle button */
        .dark-mode-btn {
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--card-bg);
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: var(--primary-green);
            width: 45px;
            height: 45px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: var(--shadow);
            transition: 0.3s;
            z-index: 1000;
        }
        .dark-mode-btn:hover {
            transform: scale(1.05);
        }

        .erro {
            background: #f8d7da;
            color: #721c24;
            padding: 0.7rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            text-align: center;
        }
        body.dark .erro {
            background: #641e24;
            color: #f9acaa;
        }

        @media (max-width: 768px) {
            .container {
                flex-direction: column;
                width: 100%;
            }
            .login-box, .info-box {
                width: 100%;
            }
            .login-box {
                padding: 40px 30px;
            }
            .info-box {
                padding: 30px 20px;
            }
        }
    </style>
</head>
<body>
    <button id="darkModeToggle" class="dark-mode-btn">🌙</button>

    <div class="container">
        <div class="login-box">
            <h2>Login</h2>
            <?php if ($erro == 'invalido'): ?>
                <div class="erro">Usuário ou senha inválidos!</div>
            <?php endif; ?>
            <form action="autenticar.php" method="POST">
                <label for="usuario">Usuário</label>
                <input type="text" id="usuario" name="usuario" placeholder="Digite seu usuário" required>

                <label for="senha">Senha</label>
                <input type="password" id="senha" name="senha" placeholder="Digite sua senha" required>

                <button type="submit">Entrar</button>
            </form>
            <p class="cadastro-texto">
                Não tem conta?
                <a href="cadastro.php">Cadastre-se</a>
            </p>
        </div>

        <div class="info-box">
            <h1>IP GRID</h1>
            <div class="info-card">
                <h3>Gerenciamento Inteligente</h3>
                <p>Substitui planilhas por um sistema centralizado de IPAM.</p>
            </div>
            <div class="info-card">
                <h3>Prevenção de Erros</h3>
                <p>Evita conflitos de IP e sobreposições automaticamente.</p>
            </div>
            <div class="info-card">
                <h3>Visualização da Rede</h3>
                <p>Mapa de calor que mostra a ocupação da rede.</p>
            </div>
            <div class="info-card">
                <h3>Preparado para o Futuro</h3>
                <p>Suporte completo para IPv6.</p>
            </div>
        </div>
    </div>

    <script>
        const darkModeToggle = document.getElementById('darkModeToggle');
        if (darkModeToggle) {
            const isDark = localStorage.getItem('darkMode') === 'true';
            if (isDark) {
                document.body.classList.add('dark');
                darkModeToggle.textContent = '☀️';
            }
            darkModeToggle.addEventListener('click', () => {
                document.body.classList.toggle('dark');
                const isDarkNow = document.body.classList.contains('dark');
                localStorage.setItem('darkMode', isDarkNow);
                darkModeToggle.textContent = isDarkNow ? '☀️' : '🌙';
            });
        }
    </script>
</body>
</html>