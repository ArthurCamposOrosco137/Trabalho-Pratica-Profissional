<?php
class IpCalculator {
    
    /**
     * Calcula todos os IPs utilizáveis de uma sub-rede
     */
    public static function calcularIPs($rede, $mascara) {
        $ips = [];
        
        // Converter rede para número binário
        $ip_long = ip2long($rede);
        $mascara_long = -1 << (32 - $mascara);
        $rede_long = $ip_long & $mascara_long;
        
        // Calcular total de IPs
        $total_ips = pow(2, 32 - $mascara);
        
        // Primeiro IP (rede) e último IP (broadcast)
        $primeiro_ip = $rede_long + 1;
        $ultimo_ip = $rede_long + $total_ips - 2;
        
        // Gerar todos os IPs utilizáveis
        for ($i = $primeiro_ip; $i <= $ultimo_ip; $i++) {
            $ips[] = long2ip($i);
        }
        
        return $ips;
    }
    
    /**
     * Calcula informações detalhadas da sub-rede
     */
    public static function infoSubrede($rede, $mascara) {
        $ip_long = ip2long($rede);
        $mascara_long = -1 << (32 - $mascara);
        $rede_long = $ip_long & $mascara_long;
        
        $total_ips = pow(2, 32 - $mascara);
        $ips_utilizaveis = $total_ips - 2;
        
        return [
            'rede' => long2ip($rede_long),
            'broadcast' => long2ip($rede_long + $total_ips - 1),
            'primeiro_ip' => long2ip($rede_long + 1),
            'ultimo_ip' => long2ip($rede_long + $total_ips - 2),
            'total_ips' => $total_ips,
            'ips_utilizaveis' => $ips_utilizaveis,
            'mascara' => $mascara,
            'mascara_decimal' => long2ip($mascara_long),
            'wildcard' => long2ip(~$mascara_long & 0xFFFFFFFF)
        ];
    }
    
    /**
     * Valida se um endereço de rede é válido
     */
    public static function validarRede($rede, $mascara) {
        if (!filter_var($rede, FILTER_VALIDATE_IP)) {
            return false;
        }
        
        $ip_long = ip2long($rede);
        $mascara_long = -1 << (32 - $mascara);
        $rede_long = $ip_long & $mascara_long;
        
        // Verificar se o IP informado é realmente o IP de rede
        return $ip_long == $rede_long;
    }
}
?>