<?php session_start(); ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Termos de Uso - IP Grid</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
            --primary: #667eea;
            --secondary: #764ba2;
            --bg-body: #f5f7fb;
            --text-primary: #333;
            --text-secondary: #666;
            --card-bg: white;
            --navbar-bg: white;
            --border-color: #eef2f7;
            --shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        body.dark {
            --bg-body: #0f172a;
            --text-primary: #e2e8f0;
            --text-secondary: #94a3b8;
            --card-bg: #1e293b;
            --navbar-bg: #0f172a;
            --border-color: #334155;
            --shadow: 0 2px 10px rgba(0,0,0,0.2);
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-body);
            color: var(--text-primary);
            transition: background 0.3s, color 0.3s;
            line-height: 1.6;
        }
        .navbar {
            background: var(--navbar-bg);
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
        }
        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .logo {
            font-size: 1.5rem;
            font-weight: bold;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .nav-links {
            display: flex;
            gap: 1.5rem;
            align-items: center;
        }
        .nav-links a {
            text-decoration: none;
            color: var(--text-secondary);
        }
        .dark-mode-btn {
            background: none;
            border: none;
            font-size: 1.3rem;
            cursor: pointer;
            color: var(--primary);
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            padding: 2rem;
            margin-top: 80px;
        }
        .card {
            background: var(--card-bg);
            border-radius: 16px;
            padding: 2rem;
            box-shadow: var(--shadow);
        }
        h1 { color: var(--primary); margin-bottom: 1rem; }
        h2 { margin-top: 1.5rem; margin-bottom: 0.5rem; font-size: 1.3rem; color: var(--primary); }
        p { margin-bottom: 1rem; }
        .footer {
            text-align: center;
            margin-top: 2rem;
            padding: 1rem;
            color: var(--text-secondary);
        }
        hr { margin: 1.5rem 0; border-color: var(--border-color); }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">🌐 IP GRID</div>
            <div class="nav-links">
                <a href="index.php">Início</a>
                <a href="dashboard.php">Dashboard</a>
                <button id="darkModeToggle" class="dark-mode-btn">🌙</button>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="card">
            <h1>📜 Termos de Uso – IP Grid</h1>
            <p><strong>Última atualização:</strong> <?php echo date('d/m/Y'); ?></p>
            <p>Bem-vindo ao IP Grid, um sistema de gerenciamento de endereços IP desenvolvido para fins acadêmicos. Ao acessar e utilizar o sistema, você concorda com os seguintes termos e condições.</p>

            <h2>1. Aceitação dos Termos</h2>
            <p>Ao se cadastrar e utilizar o IP Grid, você declara ter lido, compreendido e aceitado integralmente estes Termos de Uso, bem como a Política de Privacidade. Caso não concorde com qualquer parte, você não deve utilizar o sistema.</p>

            <h2>2. Finalidade do Sistema</h2>
            <p>O IP Grid é uma ferramenta de gerenciamento de endereços IP desenvolvida para disciplina de Prática Profissional em Programação Web. O sistema é disponibilizado <strong>sem garantias</strong> de disponibilidade contínua ou absoluta segurança, por se tratar de um projeto acadêmico.</p>

            <h2>3. Responsabilidades do Usuário</h2>
            <p>Você é responsável por manter a confidencialidade de suas credenciais de acesso. Todas as atividades realizadas em sua conta são de sua inteira responsabilidade. O uso do sistema para atividades ilegais, invasão de redes ou qualquer ação nociva é estritamente proibido.</p>

            <h2>4. Dados e Informações</h2>
            <p>Os dados inseridos no sistema (endereços IP, descrições, hostnames) são de propriedade do usuário ou da organização que representa. O IP Grid não se responsabiliza por perdas ou danos decorrentes de uso indevido das informações.</p>

            <h2>5. Propriedade Intelectual</h2>
            <p>O código-fonte, design e funcionalidades do IP Grid são de propriedade dos desenvolvedores do projeto. É permitido o uso apenas para os fins autorizados. A reprodução não autorizada é vedada.</p>

            <h2>6. Isenção de Garantias</h2>
            <p>O IP Grid é fornecido "no estado em que se encontra" (as is). Não garantimos que o sistema atenderá a todos os seus requisitos ou que estará livre de erros ou interrupções. Em nenhuma hipótese os desenvolvedores serão responsabilizados por danos diretos ou indiretos decorrentes do uso da plataforma.</p>

            <h2>7. Modificações</h2>
            <p>Estes Termos de Uso podem ser alterados a qualquer momento. As alterações entram em vigor imediatamente após a publicação. Recomendamos a revisão periódica.</p>

            <h2>8. Violação e Término</h2>
            <p>O não cumprimento destes termos poderá resultar na suspensão ou cancelamento imediato da sua conta, sem aviso prévio.</p>

            <h2>9. Contato</h2>
            <p>Em caso de dúvidas sobre estes Termos de Uso, entre em contato com os responsáveis pelo projeto.</p>
            <hr>
            <p style="text-align: center;">IP Grid © <?php echo date('Y'); ?> – Projeto Acadêmico – Todos os direitos reservados.</p>
        </div>
        <div class="footer">
            <p><a href="privacidade.php">Política de Privacidade</a> | <a href="index.php">Voltar ao início</a></p>
        </div>
    </div>

    <script>
        const toggle = document.getElementById('darkModeToggle');
        if (toggle) {
            const isDark = localStorage.getItem('darkMode') === 'true';
            if (isDark) { document.body.classList.add('dark'); toggle.textContent = '☀️'; }
            toggle.addEventListener('click', () => {
                document.body.classList.toggle('dark');
                const dark = document.body.classList.contains('dark');
                localStorage.setItem('darkMode', dark);
                toggle.textContent = dark ? '☀️' : '🌙';
            });
        }
    </script>
</body>
</html>