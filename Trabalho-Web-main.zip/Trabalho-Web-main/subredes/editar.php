<?php
session_start();
if(!isset($_SESSION["usuarioLogado"])) {
    header('Location: ../action/login.php');
    exit();
}
require_once "../config/db.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT * FROM subredes WHERE id = ?");
$stmt->execute([$id]);
$subrede = $stmt->fetch();
if (!$subrede) {
    header("Location: index.php");
    exit;
}

$erro = '';
$sucesso = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome']);
    $descricao = trim($_POST['descricao']);
    if (empty($nome)) {
        $erro = "Nome da sub-rede é obrigatório";
    } else {
        try {
            $stmt = $pdo->prepare("UPDATE subredes SET nome = ?, descricao = ? WHERE id = ?");
            $stmt->execute([$nome, $descricao, $id]);
            $sucesso = "Sub-rede atualizada com sucesso!";
            $subrede['nome'] = $nome;
            $subrede['descricao'] = $descricao;
        } catch (PDOException $e) {
            $erro = "Erro ao atualizar: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Sub-rede - IP Grid</title>
    <style>
        /* Mesmo estilo base de criar.php */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
            --primary: #667eea;
            --secondary: #764ba2;
            --bg-body: #f5f7fb;
            --text-primary: #333;
            --text-secondary: #666;
            --card-bg: white;
            --navbar-bg: white;
            --border-color: #eef2f7;
            --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --input-bg: white;
            --input-border: #ddd;
        }
        body.dark {
            --bg-body: #0f172a;
            --text-primary: #e2e8f0;
            --text-secondary: #94a3b8;
            --card-bg: #1e293b;
            --navbar-bg: #0f172a;
            --border-color: #334155;
            --shadow: 0 2px 10px rgba(0,0,0,0.2);
            --input-bg: #1e293b;
            --input-border: #475569;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-body);
            color: var(--text-primary);
            transition: background 0.3s, color 0.3s;
        }
        .navbar {
            background: var(--navbar-bg);
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
        }
        .nav-container {
            max-width: 1280px;
            margin: 0 auto;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .logo {
            font-size: 1.5rem;
            font-weight: bold;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .nav-links {
            display: flex;
            gap: 1.5rem;
            align-items: center;
        }
        .nav-links a {
            text-decoration: none;
            color: var(--text-secondary);
        }
        .dark-mode-btn {
            background: none;
            border: none;
            font-size: 1.3rem;
            cursor: pointer;
            color: var(--primary);
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 2rem;
            margin-top: 80px;
        }
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }
        .btn-primary {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 0.7rem 1.2rem;
            border-radius: 8px;
            border: none;
            cursor: pointer;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            text-decoration: none;
        }
        .form-container {
            background: var(--card-bg);
            padding: 2rem;
            border-radius: 12px;
            box-shadow: var(--shadow);
        }
        .form-group {
            margin-bottom: 1rem;
        }
        label {
            display: block;
            margin-bottom: 0.3rem;
            font-weight: bold;
        }
        input, textarea {
            width: 100%;
            padding: 0.6rem;
            border: 1px solid var(--input-border);
            border-radius: 6px;
            background: var(--input-bg);
            color: var(--text-primary);
        }
        .alert {
            padding: 0.8rem;
            border-radius: 8px;
            margin-bottom: 1rem;
        }
        .alert-error { background: #f8d7da; color: #721c24; }
        .alert-success { background: #d4edda; color: #155724; }
        body.dark .alert-error { background: #641e24; color: #f9acaa; }
        body.dark .alert-success { background: #1e4620; color: #a5d6a7; }
        .form-actions {
            display: flex;
            gap: 1rem;
            justify-content: flex-end;
            margin-top: 1.5rem;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">🌐 IP GRID</div>
            <div class="nav-links">
                <a href="../dashboard.php">Dashboard</a>
                <a href="index.php">Sub-redes</a>
                <a href="../ips/index.php">IPs</a>
                <button id="darkModeToggle" class="dark-mode-btn">🌙</button>
                <div class="user-info">
                    <span class="user-name">👤 <?php echo htmlspecialchars($_SESSION["usuarioLogado"]); ?></span>
                    <a href="../action/logout.php" class="btn-secondary">Sair</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="page-header">
            <h1>Editar Sub-rede</h1>
            <a href="index.php" class="btn-secondary">← Voltar</a>
        </div>

        <?php if ($erro): ?>
            <div class="alert alert-error"><?php echo $erro; ?></div>
        <?php endif; ?>
        <?php if ($sucesso): ?>
            <div class="alert alert-success"><?php echo $sucesso; ?></div>
        <?php endif; ?>

        <div class="form-container">
            <form method="POST" action="">
                <div class="form-group">
                    <label>Nome da Sub-rede *</label>
                    <input type="text" name="nome" value="<?php echo htmlspecialchars($subrede['nome']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Endereço de Rede</label>
                    <input type="text" value="<?php echo $subrede['rede']; ?>/<?php echo $subrede['mascara']; ?>" disabled>
                    <small>Não pode ser alterado</small>
                </div>
                <div class="form-group">
                    <label>Descrição</label>
                    <textarea name="descricao" rows="3"><?php echo htmlspecialchars($subrede['descricao']); ?></textarea>
                </div>
                <div class="form-actions">
                    <button type="button" onclick="window.location.href='index.php'" class="btn-secondary">Cancelar</button>
                    <button type="submit" class="btn-primary">Salvar Alterações</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const darkModeToggle = document.getElementById('darkModeToggle');
        if (darkModeToggle) {
            const isDark = localStorage.getItem('darkMode') === 'true';
            if (isDark) {
                document.body.classList.add('dark');
                darkModeToggle.textContent = '☀️';
            }
            darkModeToggle.addEventListener('click', () => {
                document.body.classList.toggle('dark');
                const dark = document.body.classList.contains('dark');
                localStorage.setItem('darkMode', dark);
                darkModeToggle.textContent = dark ? '☀️' : '🌙';
            });
        }
    </script>
</body>
</html>