<?php
session_start();
if(!isset($_SESSION["usuarioLogado"])) {
    header('Location: ../action/login.php');
    exit();
}

require_once "../config/db.php";

// Buscar todas as sub-redes com estatísticas
$subredes = $pdo->query("
    SELECT s.*, COUNT(i.id) as total_ips,
           SUM(CASE WHEN i.status = 'em_uso' THEN 1 ELSE 0 END) as em_uso
    FROM subredes s
    LEFT JOIN ips i ON s.id = i.subrede_id
    GROUP BY s.id
    ORDER BY s.criado_em DESC
")->fetchAll(PDO::FETCH_ASSOC);

// Calcular percentual de uso para cada sub-rede
foreach ($subredes as &$sub) {
    $sub['total_ips'] = (int)($sub['total_ips'] ?? 0);
    $sub['em_uso'] = (int)($sub['em_uso'] ?? 0);
    $sub['percentual'] = ($sub['total_ips'] > 0) ? round(($sub['em_uso'] / $sub['total_ips']) * 100) : 0;
    
    if ($sub['percentual'] <= 30) {
        $sub['status_class'] = 'otimo';
        $sub['status_label'] = 'Ótimo';
    } elseif ($sub['percentual'] <= 60) {
        $sub['status_class'] = 'normal';
        $sub['status_label'] = 'Normal';
    } elseif ($sub['percentual'] <= 85) {
        $sub['status_class'] = 'atencao';
        $sub['status_label'] = 'Atenção';
    } else {
        $sub['status_class'] = 'critico';
        $sub['status_label'] = 'Crítico';
    }
}
unset($sub);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sub-redes - IP Grid</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* ========== VARIÁVEIS DARK / LIGHT ========== */
        :root {
            --primary: #667eea;
            --secondary: #764ba2;
            --success: #22c55e;
            --warning: #eab308;
            --attention: #f97316;
            --danger: #ef4444;
            --bg-body: #f5f7fb;
            --text-primary: #333;
            --text-secondary: #666;
            --card-bg: white;
            --navbar-bg: white;
            --border-color: #eef2f7;
            --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --hover-bg: #f8f9fa;
        }

        body.dark {
            --bg-body: #0f172a;
            --text-primary: #e2e8f0;
            --text-secondary: #94a3b8;
            --card-bg: #1e293b;
            --navbar-bg: #0f172a;
            --border-color: #334155;
            --shadow: 0 2px 10px rgba(0,0,0,0.2);
            --hover-bg: #334155;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-body);
            color: var(--text-primary);
            transition: background 0.3s, color 0.3s;
        }

        /* Navbar */
        .navbar {
            background: var(--navbar-bg);
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            transition: background 0.3s;
        }

        .nav-container {
            max-width: 1280px;
            margin: 0 auto;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1rem;
        }

        .logo {
            font-size: 1.5rem;
            font-weight: bold;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            white-space: nowrap;
        }

        .nav-links {
            display: flex;
            gap: 1.25rem;
            align-items: center;
            flex-wrap: wrap;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--text-secondary);
            font-weight: 500;
            transition: color 0.3s;
        }
        .nav-links a:hover {
            color: var(--primary);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-name {
            color: var(--primary);
            font-weight: bold;
        }

        .btn-logout {
            background: #e74c3c;
            color: white;
            padding: 0.5rem 1.2rem;
            border-radius: 25px;
            text-decoration: none;
            font-size: 0.9rem;
            transition: all 0.3s;
        }
        .btn-logout:hover {
            background: #c0392b;
        }

        .dark-mode-btn {
            background: none;
            border: none;
            font-size: 1.3rem;
            cursor: pointer;
            color: var(--primary);
            padding: 0.3rem 0.6rem;
            border-radius: 50%;
            transition: background 0.3s;
        }
        .dark-mode-btn:hover {
            background: rgba(0,0,0,0.1);
        }
        body.dark .dark-mode-btn:hover {
            background: rgba(255,255,255,0.1);
        }

        .container {
            max-width: 1280px;
            margin: 0 auto;
            padding: 2rem;
            margin-top: 86px;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }
        .page-header h1 {
            color: var(--text-primary);
            font-size: 2rem;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 0.7rem 1.2rem;
            border-radius: 10px;
            text-decoration: none;
            font-size: 0.92rem;
            transition: transform 0.3s;
            display: inline-block;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
            padding: 0.45rem 1rem;
            border-radius: 8px;
            text-decoration: none;
            font-size: 0.84rem;
        }

        .subnet-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 1.5rem;
        }

        .subnet-card {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: var(--shadow);
            transition: transform 0.3s;
        }
        .subnet-card:hover {
            transform: translateY(-5px);
        }

        .subnet-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }
        .subnet-header h3 {
            color: var(--primary);
            font-size: 1.2rem;
        }

        .status-badge {
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: bold;
        }
        .status-badge.otimo { background: rgba(34,197,94,0.15); color: #16a34a; }
        .status-badge.normal { background: rgba(234,179,8,0.15); color: #ca8a04; }
        .status-badge.atencao { background: rgba(249,115,22,0.15); color: #ea580c; }
        .status-badge.critico { background: rgba(239,68,68,0.15); color: #dc2626; }
        body.dark .status-badge.otimo { background: rgba(34,197,94,0.25); color: #4ade80; }
        body.dark .status-badge.normal { background: rgba(234,179,8,0.25); color: #fde047; }
        body.dark .status-badge.atencao { background: rgba(249,115,22,0.25); color: #fdba74; }
        body.dark .status-badge.critico { background: rgba(239,68,68,0.25); color: #fca5a5; }

        .subnet-details {
            margin: 1rem 0;
            color: var(--text-secondary);
        }
        .subnet-details p {
            margin: 0.3rem 0;
        }

        .progress-bar {
            width: 100%;
            height: 8px;
            background: var(--border-color);
            border-radius: 10px;
            overflow: hidden;
            margin: 0.5rem 0;
        }
        .progress-fill {
            height: 100%;
            border-radius: 10px;
        }
        .progress-fill.otimo { background: var(--success); }
        .progress-fill.normal { background: var(--warning); }
        .progress-fill.atencao { background: var(--attention); }
        .progress-fill.critico { background: var(--danger); }

        .subnet-actions {
            display: flex;
            gap: 0.5rem;
            margin-top: 1rem;
        }
        .btn-sm {
            padding: 0.4rem 0.8rem;
            border-radius: 6px;
            text-decoration: none;
            font-size: 0.85rem;
            background: var(--primary);
            color: white;
            border: none;
            cursor: pointer;
        }
        .btn-edit {
            background: #ffc107;
            color: #333;
        }
        .btn-delete {
            background: #e74c3c;
        }
        .btn-sm:hover {
            opacity: 0.9;
        }

        .empty-state {
            text-align: center;
            padding: 3rem;
            background: var(--card-bg);
            border-radius: 12px;
            color: var(--text-secondary);
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">🌐 IP GRID IPAM</div>
            <div class="nav-links">
                <a href="../dashboard.php">Dashboard</a>
                <a href="index.php">Sub-redes</a>
                <a href="../ips/index.php">IPs</a>
                <a href="../index.php">Site</a>
                <button id="darkModeToggle" class="dark-mode-btn">🌙</button>
                <div class="user-info">
                    <span class="user-name">👤 <?php echo htmlspecialchars($_SESSION["usuarioLogado"]); ?></span>
                    <a href="../action/logout.php" class="btn-logout">Sair</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="page-header">
            <h1>Sub-redes</h1>
            <a href="criar.php" class="btn-primary">+ Nova Sub-rede</a>
        </div>

        <?php if (count($subredes) > 0): ?>
            <div class="subnet-grid">
                <?php foreach ($subredes as $sub): ?>
                    <div class="subnet-card">
                        <div class="subnet-header">
                            <h3><?php echo htmlspecialchars($sub['nome']); ?></h3>
                            <span class="status-badge <?php echo $sub['status_class']; ?>"><?php echo $sub['status_label']; ?> (<?php echo $sub['percentual']; ?>%)</span>
                        </div>
                        <div class="subnet-details">
                            <p><strong>Rede:</strong> <?php echo $sub['rede']; ?>/<?php echo $sub['mascara']; ?></p>
                            <p><strong>IPs:</strong> <?php echo $sub['em_uso']; ?>/<?php echo $sub['total_ips']; ?> em uso</p>
                            <?php if (!empty($sub['descricao'])): ?>
                                <p><strong>Descrição:</strong> <?php echo htmlspecialchars($sub['descricao']); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill <?php echo $sub['status_class']; ?>" style="width: <?php echo $sub['percentual']; ?>%"></div>
                        </div>
                        <div class="subnet-actions">
                            <a href="../ips/index.php?subrede=<?php echo $sub['id']; ?>" class="btn-sm">🔍 Ver IPs</a>
                            <a href="editar.php?id=<?php echo $sub['id']; ?>" class="btn-sm btn-edit">✏️ Editar</a>
                            <a href="excluir.php?id=<?php echo $sub['id']; ?>" class="btn-sm btn-delete" onclick="return confirm('Tem certeza que deseja excluir esta sub-rede? Todos os IPs associados serão deletados.')">🗑️ Excluir</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <footer style="text-align: center; padding: 2rem; color: #888; margin-top: 2rem;">
    <p>IP Grid © 2026 - Gerenciamento de Sub-redes</p>
    <p><a href="../termos.php" style="color: #667eea;">📜 Política de Privacidade e Termos de Uso</a></p>
</footer>
        <?php else: ?>
            <div class="empty-state">
                <p>Nenhuma sub-rede cadastrada ainda.</p>
                <a href="criar.php" class="btn-primary" style="margin-top: 1rem; display: inline-block;">Criar primeira sub-rede</a>
            </div>
        <?php endif; ?>
    </div>

    <script>
        // Dark mode toggle
        const darkModeToggle = document.getElementById('darkModeToggle');
        if (darkModeToggle) {
            const isDark = localStorage.getItem('darkMode') === 'true';
            if (isDark) {
                document.body.classList.add('dark');
                darkModeToggle.textContent = '☀️';
            }
            darkModeToggle.addEventListener('click', () => {
                document.body.classList.toggle('dark');
                const isDarkNow = document.body.classList.contains('dark');
                localStorage.setItem('darkMode', isDarkNow);
                darkModeToggle.textContent = isDarkNow ? '☀️' : '🌙';
            });
        }
    </script>
</body>
</html>