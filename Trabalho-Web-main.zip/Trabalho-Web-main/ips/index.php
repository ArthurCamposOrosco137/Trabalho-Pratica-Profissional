<?php
session_start();
if(!isset($_SESSION["usuarioLogado"])) {
    header('Location: ../action/login.php');
    exit();
}

require_once "../config/db.php";

$subrede_id = isset($_GET['subrede']) ? (int)$_GET['subrede'] : 0;

// Buscar sub-redes para o filtro
$subredes = $pdo->query("SELECT id, nome, rede, mascara FROM subredes ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);

// Buscar IPs da sub-rede selecionada
$ips = [];
$subrede_atual = null;
$ips_livres_count = 0;

if ($subrede_id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM subredes WHERE id = ?");
    $stmt->execute([$subrede_id]);
    $subrede_atual = $stmt->fetch();
    
    if ($subrede_atual) {
        $stmt = $pdo->prepare("SELECT * FROM ips WHERE subrede_id = ? ORDER BY INET_ATON(endereco)");
        $stmt->execute([$subrede_id]);
        $ips = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Contar IPs livres
        $stmt2 = $pdo->prepare("SELECT COUNT(*) as livres FROM ips WHERE subrede_id = ? AND status = 'livre'");
        $stmt2->execute([$subrede_id]);
        $ips_livres_count = $stmt2->fetch()['livres'];
    }
}

// Processar ações
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // CRIAÇÃO EM MASSA
    if(isset($_POST['bulk_create'])) {
        $quantidade = (int)$_POST['quantidade'];
        $base_nome = trim($_POST['base_nome']);
        $responsavel = trim($_POST['responsavel']);
        $descricao = trim($_POST['descricao_bulk']);
        
        if(empty($base_nome)) {
            $_SESSION['erro'] = "Informe um nome base para os IPs";
        } else {
            try {
                $pdo->beginTransaction();
                
                // Buscar IPs livres
                $stmt = $pdo->prepare("
                    SELECT id, endereco FROM ips 
                    WHERE subrede_id = ? AND status = 'livre' 
                    ORDER BY INET_ATON(endereco) 
                    LIMIT " . (int)$quantidade . "
                ");
                $stmt->execute([$subrede_id]);
                $ips_livres = $stmt->fetchAll();
                
                if(count($ips_livres) < $quantidade) {
                    $_SESSION['erro'] = "Apenas " . count($ips_livres) . " IPs livres disponíveis";
                } else {
                    $contador = 1;
                    $criados = [];
                    
                    foreach($ips_livres as $ip) {
                        $hostname = $base_nome . $contador;
                        $stmt_update = $pdo->prepare("
                            UPDATE ips 
                            SET status = 'em_uso', 
                                hostname = ?, 
                                responsavel = ?, 
                                descricao = ?,
                                reservado_em = NOW()
                            WHERE id = ?
                        ");
                        $stmt_update->execute([$hostname, $responsavel, $descricao, $ip['id']]);
                        
                        $criados[] = $ip['endereco'] . " → " . $hostname;
                        $contador++;
                    }
                    
                    $pdo->commit();
                    $_SESSION['mensagem'] = "✅ $quantidade IPs criados com sucesso!<br>" . implode("<br>", array_slice($criados, 0, 10)) . (count($criados) > 10 ? "<br>... e mais " . (count($criados) - 10) . " IPs" : "");
                }
            } catch(Exception $e) {
                $pdo->rollBack();
                $_SESSION['erro'] = "Erro: " . $e->getMessage();
            }
        }
        
        header("Location: index.php?subrede=" . $subrede_id);
        exit;
    }
    
    // RESERVAR IP INDIVIDUAL
    if(isset($_POST['acao']) && $_POST['acao'] == 'reservar') {
        $ip_id = (int)$_POST['ip_id'];
        $hostname = trim($_POST['hostname']);
        $responsavel = trim($_POST['responsavel']);
        $descricao = trim($_POST['descricao']);
        
        $stmt = $pdo->prepare("UPDATE ips SET status = 'em_uso', hostname = ?, responsavel = ?, descricao = ?, reservado_em = NOW() WHERE id = ?");
        $stmt->execute([$hostname, $responsavel, $descricao, $ip_id]);
        $_SESSION['mensagem'] = "IP reservado com sucesso!";
        
        header("Location: index.php?subrede=" . $subrede_id);
        exit;
    }
    
    // LIBERAR IP
    if(isset($_POST['acao']) && $_POST['acao'] == 'liberar') {
        $ip_id = (int)$_POST['ip_id'];
        $stmt = $pdo->prepare("UPDATE ips SET status = 'livre', hostname = NULL, responsavel = NULL, descricao = NULL, reservado_em = NULL WHERE id = ?");
        $stmt->execute([$ip_id]);
        $_SESSION['mensagem'] = "IP liberado com sucesso!";
        
        header("Location: index.php?subrede=" . $subrede_id);
        exit;
    }
}

$mensagem = isset($_SESSION['mensagem']) ? $_SESSION['mensagem'] : '';
$erro = isset($_SESSION['erro']) ? $_SESSION['erro'] : '';
unset($_SESSION['mensagem'], $_SESSION['erro']);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar IPs - IP Grid</title>
    <link rel="stylesheet" href="../assets/dashboard.css">
    <style>
        .filtro-subrede {
            background: white;
            padding: 1.5rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .ip-status {
            display: inline-block;
            padding: 0.2rem 0.6rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: bold;
        }
        
        .status-livre { background: #d4edda; color: #155724; }
        .status-em_uso { background: #f8d7da; color: #721c24; }
        .status-reservado { background: #fff3cd; color: #856404; }
        
        .ip-actions {
            display: flex;
            gap: 0.5rem;
        }
        
        .btn-sm {
            padding: 0.3rem 0.8rem;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.8rem;
        }
        
        .btn-reservar { background: #28a745; color: white; }
        .btn-reservar:hover { background: #218838; }
        .btn-liberar { background: #dc3545; color: white; }
        .btn-liberar:hover { background: #c82333; }
        .btn-bulk { background: #17a2b8; color: white; }
        .btn-bulk:hover { background: #138496; }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 2000;
            justify-content: center;
            align-items: center;
        }
        
        .modal-content {
            background: white;
            padding: 2rem;
            border-radius: 12px;
            max-width: 500px;
            width: 90%;
        }
        
        .modal-content h3 {
            margin-bottom: 1rem;
        }
        
        .modal-buttons {
            display: flex;
            gap: 1rem;
            justify-content: flex-end;
            margin-top: 1.5rem;
        }
        
        .form-group {
            margin-bottom: 1rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.3rem;
            font-weight: bold;
        }
        
        .form-group input, .form-group textarea, .form-group select {
            width: 100%;
            padding: 0.5rem;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .alert {
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem;
            background: white;
            border-radius: 12px;
        }
        
        .bulk-bar {
            background: white;
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .stats-badge {
            background: #e9ecef;
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.85rem;
        }
        
        .table-container {
            overflow-x: auto;
            background: white;
            border-radius: 12px;
            padding: 1rem;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #dee2e6;
        }
        
        th {
            background: #f8f9fa;
            font-weight: bold;
        }
        
        tr:hover {
            background: #f8f9fa;
        }
        
        /* Estilos para edição inline */
        .editable-field {
            cursor: pointer;
            transition: background 0.2s;
            padding: 2px 4px;
            border-radius: 4px;
            display: inline-block;
        }
        
        .editable-field:hover {
            background: #f0f0f0;
        }
        
        .editable-input {
            width: 150px;
            padding: 4px 6px;
            border: 1px solid #667eea;
            border-radius: 4px;
            font-size: 0.85rem;
            font-family: monospace;
        }
        
        .editable-input:focus {
            outline: none;
            border-color: #764ba2;
            box-shadow: 0 0 0 2px rgba(102, 126, 234, 0.2);
        }
        
        .editable-saving {
            color: #ff9800;
            font-size: 0.7rem;
            margin-left: 5px;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">🌐 IP GRID</div>
            <div class="nav-links">
                <a href="../dashboard.php">Dashboard</a>
                <a href="../subredes/index.php">Sub-redes</a>
                <a href="index.php">IPs</a>
                <a href="../index.php">Site</a>
                <div class="user-info">
                    <span class="user-name">👤 <?php echo htmlspecialchars($_SESSION["usuarioLogado"]); ?></span>
                    <a href="../action/logout.php" class="btn-logout">Sair</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container" style="max-width: 1400px; margin: 0 auto; padding: 2rem; margin-top: 80px;">
        <div class="page-header">
            <h1>Gerenciar IPs</h1>
        </div>

        <?php if ($mensagem): ?>
            <div class="alert alert-success"><?php echo $mensagem; ?></div>
        <?php endif; ?>
        
        <?php if ($erro): ?>
            <div class="alert alert-error"><?php echo $erro; ?></div>
        <?php endif; ?>

        <div class="filtro-subrede">
            <h3>Selecione uma Sub-rede</h3>
            <select id="subrede_select" onchange="window.location.href='index.php?subrede=' + this.value" style="width: 100%; padding: 0.8rem; margin-top: 1rem;">
                <option value="">-- Selecione uma sub-rede --</option>
                <?php foreach ($subredes as $sub): ?>
                    <option value="<?php echo $sub['id']; ?>" <?php echo $subrede_id == $sub['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($sub['nome']); ?> (<?php echo $sub['rede']; ?>/<?php echo $sub['mascara']; ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <?php if ($subrede_atual): ?>
            <!-- Barra de ações em massa -->
            <div class="bulk-bar">
                <div>
                    <span class="stats-badge">📊 IPs livres: <strong><?php echo $ips_livres_count; ?></strong></span>
                </div>
                <div>
                    <button onclick="abrirModalBulk()" class="btn-sm btn-bulk" <?php echo $ips_livres_count == 0 ? 'disabled' : ''; ?>>
                        🚀 Ocupar IPs em Massa
                    </button>
                </div>
            </div>
            
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Endereço IP</th>
                            <th>Status</th>
                            <th>Hostname</th>
                            <th>Responsável</th>
                            <th>Descrição</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($ips as $ip): ?>
                            <tr>
                                <td><strong><?php echo $ip['endereco']; ?></strong></td>
                                <td>
                                    <span class="ip-status status-<?php echo $ip['status']; ?>">
                                        <?php 
                                        switch($ip['status']) {
                                            case 'livre': echo '🟢 Livre'; break;
                                            case 'em_uso': echo '🔴 Em uso'; break;
                                            case 'reservado': echo '🟡 Reservado'; break;
                                            default: echo $ip['status'];
                                        }
                                        ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="editable-field" ondblclick="editarHostnameInline(<?php echo $ip['id']; ?>, this)">
                                        <?php echo htmlspecialchars($ip['hostname'] ?? '-'); ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($ip['responsavel'] ?? '-'); ?></td>
                                <td>
                                    <span class="editable-field" ondblclick="editarDescricaoInline(<?php echo $ip['id']; ?>, this)">
                                        <?php echo htmlspecialchars($ip['descricao'] ?? '-'); ?>
                                    </span>
                                </td>
                                <td class="ip-actions">
                                    <?php if ($ip['status'] == 'livre'): ?>
                                        <button onclick="abrirModalReservar(<?php echo $ip['id']; ?>, '<?php echo $ip['endereco']; ?>')" class="btn-sm btn-reservar">Reservar</button>
                                    <?php elseif ($ip['status'] == 'em_uso'): ?>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="ip_id" value="<?php echo $ip['id']; ?>">
                                            <input type="hidden" name="acao" value="liberar">
                                            <button type="submit" class="btn-sm btn-liberar" onclick="return confirm('Tem certeza que deseja liberar este IP?')">Liberar</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php elseif ($subrede_id == 0 && count($subredes) > 0): ?>
            <div class="empty-state">
                <p>Selecione uma sub-rede para visualizar os IPs.</p>
            </div>
        <?php elseif (count($subredes) == 0): ?>
            <div class="empty-state">
                <p>Nenhuma sub-rede cadastrada.</p>
                <a href="../subredes/criar.php" class="btn-primary">Criar primeira sub-rede</a>
            </div>
        <?php endif; ?>
    </div>

    <!-- Modal para reservar IP individual -->
    <div id="modalReservar" class="modal">
        <div class="modal-content">
            <h3>Reservar IP</h3>
            <form method="POST" action="">
                <input type="hidden" name="ip_id" id="modal_ip_id">
                <input type="hidden" name="acao" value="reservar">
                
                <div class="form-group">
                    <label>Endereço IP</label>
                    <input type="text" id="modal_ip_endereco" disabled style="background: #f5f5f5;">
                </div>
                
                <div class="form-group">
                    <label for="hostname">Hostname</label>
                    <input type="text" id="hostname" name="hostname" placeholder="Ex: servidor-web-01">
                </div>
                
                <div class="form-group">
                    <label for="responsavel">Responsável</label>
                    <input type="text" id="responsavel" name="responsavel" placeholder="Nome do responsável">
                </div>
                
                <div class="form-group">
                    <label for="descricao">Descrição</label>
                    <textarea id="descricao" name="descricao" rows="3" placeholder="Descrição do uso deste IP"></textarea>
                </div>
                
                <div class="modal-buttons">
                    <button type="button" onclick="fecharModalReservar()" class="btn-secondary">Cancelar</button>
                    <button type="submit" class="btn-primary">Reservar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal para criação em massa -->
    <div id="modalBulk" class="modal">
        <div class="modal-content">
            <h3>🚀 Ocupar IPs em Massa</h3>
            <p style="color: #666; margin-bottom: 1rem;">Crie vários IPs de uma só vez com nomeação automática!</p>
            
            <form method="POST" action="">
                <input type="hidden" name="bulk_create" value="1">
                
                <div class="form-group">
                    <label>Quantidade de IPs:</label>
                    <input type="number" name="quantidade" id="bulk_quantidade" min="1" max="<?php echo $ips_livres_count; ?>" value="10" required>
                    <small style="color: #666;">Máximo disponível: <?php echo $ips_livres_count; ?> IPs livres</small>
                </div>
                
                <div class="form-group">
                    <label>Nome base:</label>
                    <input type="text" name="base_nome" id="bulk_base_nome" placeholder="Ex: computador, servidor" required>
                    <small style="color: #666;">Os IPs serão nomeados como: NomeBase1, NomeBase2...</small>
                </div>
                
                <div class="form-group">
                    <label>Responsável:</label>
                    <input type="text" name="responsavel" id="bulk_responsavel" value="<?php echo htmlspecialchars($_SESSION["usuarioLogado"]); ?>">
                </div>
                
                <div class="form-group">
                    <label>Descrição (opcional):</label>
                    <textarea name="descricao_bulk" id="bulk_descricao" rows="3" placeholder="Descrição geral para estes IPs..."></textarea>
                </div>
                
                <div class="modal-buttons">
                    <button type="button" onclick="fecharModalBulk()" class="btn-secondary">Cancelar</button>
                    <button type="submit" class="btn-primary">✅ Confirmar Ocupação</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // ==================== FUNÇÕES DOS MODAIS ====================
        
        function abrirModalReservar(ipId, ipEndereco) {
            document.getElementById('modal_ip_id').value = ipId;
            document.getElementById('modal_ip_endereco').value = ipEndereco;
            document.getElementById('modalReservar').style.display = 'flex';
        }
        
        function fecharModalReservar() {
            document.getElementById('modalReservar').style.display = 'none';
        }
        
        function abrirModalBulk() {
            document.getElementById('modalBulk').style.display = 'flex';
        }
        
        function fecharModalBulk() {
            document.getElementById('modalBulk').style.display = 'none';
        }
        
        // Fechar modais ao clicar fora
        window.onclick = function(event) {
            const modalReservar = document.getElementById('modalReservar');
            const modalBulk = document.getElementById('modalBulk');
            if (event.target == modalReservar) {
                fecharModalReservar();
            }
            if (event.target == modalBulk) {
                fecharModalBulk();
            }
        }
        
        // Preview do nome base
        const quantidadeInput = document.getElementById('bulk_quantidade');
        const baseNomeInput = document.getElementById('bulk_base_nome');
        
        function atualizarPreview() {
            const quantidade = quantidadeInput ? quantidadeInput.value : 10;
            const baseNome = baseNomeInput ? baseNomeInput.value : '';
        }
        
        if(quantidadeInput && baseNomeInput) {
            quantidadeInput.oninput = atualizarPreview;
            baseNomeInput.oninput = atualizarPreview;
        }
        
        // ==================== FUNÇÕES DE EDIÇÃO INLINE ====================
        
        // Função para editar hostname inline (duplo clique)
        function editarHostnameInline(ipId, elemento) {
            const hostnameAtual = elemento.textContent.trim();
            const td = elemento.parentElement;
            
            // Criar input
            const input = document.createElement('input');
            input.type = 'text';
            input.value = hostnameAtual === '-' ? '' : hostnameAtual;
            input.className = 'editable-input';
            input.placeholder = 'Digite o novo hostname';
            
            // Criar indicador de salvamento
            const savingSpan = document.createElement('span');
            savingSpan.className = 'editable-saving';
            savingSpan.textContent = ' ⏳';
            savingSpan.style.display = 'none';
            
            // Substituir o texto pelo input
            elemento.style.display = 'none';
            td.insertBefore(input, elemento);
            td.insertBefore(savingSpan, elemento.nextSibling);
            
            input.focus();
            
            // Salvar ao pressionar Enter
            input.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    salvarHostname(ipId, input.value, elemento, input, savingSpan);
                }
            });
            
            // Salvar ao perder foco
            input.addEventListener('blur', function() {
                if (input.value !== (hostnameAtual === '-' ? '' : hostnameAtual)) {
                    salvarHostname(ipId, input.value, elemento, input, savingSpan);
                } else {
                    // Cancelar edição
                    elemento.style.display = 'inline-block';
                    input.remove();
                    savingSpan.remove();
                }
            });
            
            // Cancelar ao pressionar ESC
            input.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') {
                    elemento.style.display = 'inline-block';
                    input.remove();
                    savingSpan.remove();
                }
            });
        }
        
        // Função para salvar o hostname via AJAX
        function salvarHostname(ipId, novoHostname, elemento, input, savingSpan) {
            savingSpan.style.display = 'inline';
            
            fetch('../api/ips.php', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    id: ipId,
                    hostname: novoHostname || null
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Atualizar o texto
                    if (novoHostname && novoHostname.trim() !== '') {
                        elemento.textContent = novoHostname;
                    } else {
                        elemento.textContent = '-';
                    }
                    elemento.style.display = 'inline-block';
                    
                    // Feedback visual rápido
                    savingSpan.textContent = ' ✓';
                    setTimeout(() => {
                        savingSpan.remove();
                    }, 500);
                } else {
                    throw new Error(data.error || 'Erro ao salvar');
                }
            })
            .catch(error => {
                savingSpan.textContent = ' ❌';
                setTimeout(() => {
                    savingSpan.remove();
                }, 1000);
                console.error('Erro:', error);
            })
            .finally(() => {
                input.remove();
            });
        }
        
        // Função para editar descrição inline (duplo clique)
        function editarDescricaoInline(ipId, elemento) {
            const descricaoAtual = elemento.textContent.trim();
            const td = elemento.parentElement;
            
            // Criar input
            const input = document.createElement('input');
            input.type = 'text';
            input.value = descricaoAtual === '-' ? '' : descricaoAtual;
            input.className = 'editable-input';
            input.placeholder = 'Digite a descrição';
            input.style.width = '200px';
            
            // Criar indicador de salvamento
            const savingSpan = document.createElement('span');
            savingSpan.className = 'editable-saving';
            savingSpan.textContent = ' ⏳';
            savingSpan.style.display = 'none';
            
            // Substituir o texto pelo input
            elemento.style.display = 'none';
            td.insertBefore(input, elemento);
            td.insertBefore(savingSpan, elemento.nextSibling);
            
            input.focus();
            
            // Salvar ao pressionar Enter
            input.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    salvarDescricao(ipId, input.value, elemento, input, savingSpan);
                }
            });
            
            // Salvar ao perder foco
            input.addEventListener('blur', function() {
                if (input.value !== (descricaoAtual === '-' ? '' : descricaoAtual)) {
                    salvarDescricao(ipId, input.value, elemento, input, savingSpan);
                } else {
                    elemento.style.display = 'inline-block';
                    input.remove();
                    savingSpan.remove();
                }
            });
            
            input.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') {
                    elemento.style.display = 'inline-block';
                    input.remove();
                    savingSpan.remove();
                }
            });
        }
        
        // Função para salvar a descrição via AJAX
        function salvarDescricao(ipId, novaDescricao, elemento, input, savingSpan) {
            savingSpan.style.display = 'inline';
            
            fetch('../api/ips.php', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    id: ipId,
                    descricao: novaDescricao || null
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    if (novaDescricao && novaDescricao.trim() !== '') {
                        elemento.textContent = novaDescricao;
                    } else {
                        elemento.textContent = '-';
                    }
                    elemento.style.display = 'inline-block';
                    savingSpan.textContent = ' ✓';
                    setTimeout(() => {
                        savingSpan.remove();
                    }, 500);
                } else {
                    throw new Error(data.error || 'Erro ao salvar');
                }
            })
            .catch(error => {
                savingSpan.textContent = ' ❌';
                setTimeout(() => {
                    savingSpan.remove();
                }, 1000);
                console.error('Erro:', error);
            })
            .finally(() => {
                input.remove();
            });
        }
    </script>
</body>
</html>