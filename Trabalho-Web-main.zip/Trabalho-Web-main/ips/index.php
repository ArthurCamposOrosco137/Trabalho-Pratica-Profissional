<?php
session_start();
if(!isset($_SESSION["usuarioLogado"])) {
    header('Location: ../action/login.php');
    exit();
}

require_once "../config/db.php";

$subrede_id = isset($_GET['subrede']) ? (int)$_GET['subrede'] : 0;

// Buscar sub-redes para o filtro
$subredes = $pdo->query("SELECT id, nome, rede, mascara FROM subredes ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);

// Buscar IPs da sub-rede selecionada
$ips = [];
$subrede_atual = null;
$ips_livres_count = 0;

if ($subrede_id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM subredes WHERE id = ?");
    $stmt->execute([$subrede_id]);
    $subrede_atual = $stmt->fetch();
    
    if ($subrede_atual) {
        $stmt = $pdo->prepare("SELECT * FROM ips WHERE subrede_id = ? ORDER BY INET_ATON(endereco)");
        $stmt->execute([$subrede_id]);
        $ips = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Contar IPs livres
        $stmt2 = $pdo->prepare("SELECT COUNT(*) as livres FROM ips WHERE subrede_id = ? AND status = 'livre'");
        $stmt2->execute([$subrede_id]);
        $ips_livres_count = $stmt2->fetch()['livres'];
    }
}

// Processar ações
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // CRIAÇÃO EM MASSA
    if(isset($_POST['bulk_create'])) {
        $quantidade = (int)$_POST['quantidade'];
        $base_nome = trim($_POST['base_nome']);
        $responsavel = trim($_POST['responsavel']);
        $descricao = trim($_POST['descricao_bulk']);
        
        if(empty($base_nome)) {
            $_SESSION['erro'] = "Informe um nome base para os IPs";
        } else {
            try {
                $pdo->beginTransaction();
                
                // Buscar IPs livres
                $stmt = $pdo->prepare("
                    SELECT id, endereco FROM ips 
                    WHERE subrede_id = ? AND status = 'livre' 
                    ORDER BY INET_ATON(endereco) 
                    LIMIT " . (int)$quantidade . "
                ");
                $stmt->execute([$subrede_id]);
                $ips_livres = $stmt->fetchAll();
                
                if(count($ips_livres) < $quantidade) {
                    $_SESSION['erro'] = "Apenas " . count($ips_livres) . " IPs livres disponíveis";
                } else {
                    $contador = 1;
                    $criados = [];
                    
                    foreach($ips_livres as $ip) {
                        $hostname = $base_nome . $contador;
                        $stmt_update = $pdo->prepare("
                            UPDATE ips 
                            SET status = 'em_uso', 
                                hostname = ?, 
                                responsavel = ?, 
                                descricao = ?,
                                reservado_em = NOW()
                            WHERE id = ?
                        ");
                        $stmt_update->execute([$hostname, $responsavel, $descricao, $ip['id']]);
                        
                        $criados[] = $ip['endereco'] . " → " . $hostname;
                        $contador++;
                    }
                    
                    $pdo->commit();
                    $_SESSION['mensagem'] = "✅ $quantidade IPs criados com sucesso!<br>" . implode("<br>", array_slice($criados, 0, 10)) . (count($criados) > 10 ? "<br>... e mais " . (count($criados) - 10) . " IPs" : "");
                }
            } catch(Exception $e) {
                $pdo->rollBack();
                $_SESSION['erro'] = "Erro: " . $e->getMessage();
            }
        }
        
        header("Location: index.php?subrede=" . $subrede_id);
        exit;
    }
    
    // RESERVAR IP INDIVIDUAL
    if(isset($_POST['acao']) && $_POST['acao'] == 'reservar') {
        $ip_id = (int)$_POST['ip_id'];
        $hostname = trim($_POST['hostname']);
        $responsavel = trim($_POST['responsavel']);
        $descricao = trim($_POST['descricao']);
        
        $stmt = $pdo->prepare("UPDATE ips SET status = 'em_uso', hostname = ?, responsavel = ?, descricao = ?, reservado_em = NOW() WHERE id = ?");
        $stmt->execute([$hostname, $responsavel, $descricao, $ip_id]);
        $_SESSION['mensagem'] = "IP reservado com sucesso!";
        
        header("Location: index.php?subrede=" . $subrede_id);
        exit;
    }
    
    // LIBERAR IP
    if(isset($_POST['acao']) && $_POST['acao'] == 'liberar') {
        $ip_id = (int)$_POST['ip_id'];
        $stmt = $pdo->prepare("UPDATE ips SET status = 'livre', hostname = NULL, responsavel = NULL, descricao = NULL, reservado_em = NULL WHERE id = ?");
        $stmt->execute([$ip_id]);
        $_SESSION['mensagem'] = "IP liberado com sucesso!";
        
        header("Location: index.php?subrede=" . $subrede_id);
        exit;
    }
}

$mensagem = isset($_SESSION['mensagem']) ? $_SESSION['mensagem'] : '';
$erro = isset($_SESSION['erro']) ? $_SESSION['erro'] : '';
unset($_SESSION['mensagem'], $_SESSION['erro']);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar IPs - IP Grid</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* ========== VARIÁVEIS DARK / LIGHT ========== */
        :root {
            --primary: #667eea;
            --secondary: #764ba2;
            --success: #22c55e;
            --warning: #eab308;
            --danger: #ef4444;
            --bg-body: #f5f7fb;
            --text-primary: #333;
            --text-secondary: #666;
            --card-bg: white;
            --navbar-bg: white;
            --border-color: #eef2f7;
            --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --input-bg: white;
            --input-border: #ddd;
            --table-header-bg: #f8f9fa;
            --table-border: #dee2e6;
            --hover-bg: #f8f9fa;
        }

        body.dark {
            --bg-body: #0f172a;
            --text-primary: #e2e8f0;
            --text-secondary: #94a3b8;
            --card-bg: #1e293b;
            --navbar-bg: #0f172a;
            --border-color: #334155;
            --shadow: 0 2px 10px rgba(0,0,0,0.2);
            --input-bg: #1e293b;
            --input-border: #475569;
            --table-header-bg: #334155;
            --table-border: #475569;
            --hover-bg: #334155;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-body);
            color: var(--text-primary);
            transition: background 0.3s, color 0.3s;
        }

        /* Navbar */
        .navbar {
            background: var(--navbar-bg);
            box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            transition: background 0.3s;
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1rem;
        }

        .logo {
            font-size: 1.5rem;
            font-weight: bold;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            white-space: nowrap;
        }

        .nav-links {
            display: flex;
            gap: 1.5rem;
            align-items: center;
            flex-wrap: wrap;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--text-secondary);
            font-weight: 500;
            transition: color 0.3s;
        }
        .nav-links a:hover {
            color: var(--primary);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-name {
            color: var(--primary);
            font-weight: bold;
        }

        .btn-logout {
            background: #e74c3c;
            color: white;
            padding: 0.5rem 1.2rem;
            border-radius: 25px;
            text-decoration: none;
            font-size: 0.9rem;
            transition: all 0.3s;
        }
        .btn-logout:hover {
            background: #c0392b;
        }

        .dark-mode-btn {
            background: none;
            border: none;
            font-size: 1.3rem;
            cursor: pointer;
            color: var(--primary);
            padding: 0.3rem 0.6rem;
            border-radius: 50%;
            transition: background 0.3s;
        }
        .dark-mode-btn:hover {
            background: rgba(0,0,0,0.1);
        }
        body.dark .dark-mode-btn:hover {
            background: rgba(255,255,255,0.1);
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem;
            margin-top: 80px;
        }

        .page-header {
            margin-bottom: 2rem;
        }
        .page-header h1 {
            color: var(--text-primary);
        }

        .filtro-subrede {
            background: var(--card-bg);
            padding: 1.5rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            box-shadow: var(--shadow);
        }
        .filtro-subrede h3 {
            margin-bottom: 1rem;
            color: var(--text-primary);
        }
        #subrede_select {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid var(--input-border);
            border-radius: 8px;
            background: var(--input-bg);
            color: var(--text-primary);
        }

        .bulk-bar {
            background: var(--card-bg);
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1rem;
            box-shadow: var(--shadow);
        }
        .stats-badge {
            background: var(--hover-bg);
            padding: 0.3rem 0.8rem;
            border-radius: 20px;
            font-size: 0.85rem;
            color: var(--text-primary);
        }
        .btn-sm {
            padding: 0.3rem 0.8rem;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.8rem;
        }
        .btn-reservar { background: #28a745; color: white; }
        .btn-liberar { background: #dc3545; color: white; }
        .btn-bulk { background: #17a2b8; color: white; }
        .btn-primary {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 0.7rem 1.2rem;
            border-radius: 8px;
            border: none;
            cursor: pointer;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            border: none;
            cursor: pointer;
        }
        .table-container {
            overflow-x: auto;
            background: var(--card-bg);
            border-radius: 12px;
            padding: 1rem;
            box-shadow: var(--shadow);
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid var(--table-border);
        }
        th {
            background: var(--table-header-bg);
            color: var(--text-primary);
        }
        tr:hover {
            background: var(--hover-bg);
        }
        .ip-status {
            display: inline-block;
            padding: 0.2rem 0.6rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: bold;
        }
        .status-livre { background: #d4edda; color: #155724; }
        .status-em_uso { background: #f8d7da; color: #721c24; }
        .status-reservado { background: #fff3cd; color: #856404; }
        body.dark .status-livre { background: #1e4620; color: #a5d6a7; }
        body.dark .status-em_uso { background: #641e24; color: #f9acaa; }
        body.dark .status-reservado { background: #664d03; color: #ffe69e; }

        /* Edição inline */
        .editable-field {
            cursor: pointer;
            transition: background 0.2s;
            padding: 2px 4px;
            border-radius: 4px;
            display: inline-block;
        }
        .editable-field:hover {
            background: var(--hover-bg);
        }
        .editable-input {
            width: 150px;
            padding: 4px 6px;
            border: 1px solid var(--primary);
            border-radius: 4px;
            font-size: 0.85rem;
            background: var(--input-bg);
            color: var(--text-primary);
        }
        .editable-saving {
            color: #ff9800;
            font-size: 0.7rem;
            margin-left: 5px;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 2000;
            justify-content: center;
            align-items: center;
        }
        .modal-content {
            background: var(--card-bg);
            padding: 2rem;
            border-radius: 12px;
            max-width: 500px;
            width: 90%;
            color: var(--text-primary);
        }
        .form-group {
            margin-bottom: 1rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.3rem;
            font-weight: bold;
        }
        .form-group input, .form-group textarea, .form-group select {
            width: 100%;
            padding: 0.5rem;
            border: 1px solid var(--input-border);
            border-radius: 4px;
            background: var(--input-bg);
            color: var(--text-primary);
        }
        .modal-buttons {
            display: flex;
            gap: 1rem;
            justify-content: flex-end;
            margin-top: 1.5rem;
        }
        .alert {
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        body.dark .alert-success {
            background: #1e4620;
            color: #a5d6a7;
        }
        body.dark .alert-error {
            background: #641e24;
            color: #f9acaa;
        }
        .empty-state {
            text-align: center;
            padding: 3rem;
            background: var(--card-bg);
            border-radius: 12px;
            color: var(--text-secondary);
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">🌐 IP GRID</div>
            <div class="nav-links">
                <a href="../dashboard.php">Dashboard</a>
                <a href="../subredes/index.php">Sub-redes</a>
                <a href="index.php">IPs</a>
                <a href="../index.php">Site</a>
                <button id="darkModeToggle" class="dark-mode-btn">🌙</button>
                <div class="user-info">
                    <span class="user-name">👤 <?php echo htmlspecialchars($_SESSION["usuarioLogado"]); ?></span>
                    <a href="../action/logout.php" class="btn-logout">Sair</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="page-header">
            <h1>Gerenciar IPs</h1>
        </div>

        <?php if ($mensagem): ?>
            <div class="alert alert-success"><?php echo $mensagem; ?></div>
        <?php endif; ?>
        <?php if ($erro): ?>
            <div class="alert alert-error"><?php echo $erro; ?></div>
        <?php endif; ?>

        <div class="filtro-subrede">
            <h3>Selecione uma Sub-rede</h3>
            <select id="subrede_select" onchange="window.location.href='index.php?subrede=' + this.value">
                <option value="">-- Selecione uma sub-rede --</option>
                <?php foreach ($subredes as $sub): ?>
                    <option value="<?php echo $sub['id']; ?>" <?php echo $subrede_id == $sub['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($sub['nome']); ?> (<?php echo $sub['rede']; ?>/<?php echo $sub['mascara']; ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <?php if ($subrede_atual): ?>
            <div class="bulk-bar">
                <div><span class="stats-badge">📊 IPs livres: <strong><?php echo $ips_livres_count; ?></strong></span></div>
                <button onclick="abrirModalBulk()" class="btn-sm btn-bulk" <?php echo $ips_livres_count == 0 ? 'disabled' : ''; ?>>🚀 Ocupar IPs em Massa</button>
            </div>
            <div class="table-container">
                <table>
                    <thead>
                        <tr><th>Endereço IP</th><th>Status</th><th>Hostname</th><th>Responsável</th><th>Descrição</th><th>Ações</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($ips as $ip): ?>
                            <tr>
                                <td><strong><?php echo $ip['endereco']; ?></strong></td>
                                <td><span class="ip-status status-<?php echo $ip['status']; ?>"><?php echo ucfirst(str_replace('_', ' ', $ip['status'])); ?></span></td>
                                <td><span class="editable-field" ondblclick="editarHostnameInline(<?php echo $ip['id']; ?>, this)"><?php echo htmlspecialchars($ip['hostname'] ?? '-'); ?></span></td>
                                <td><?php echo htmlspecialchars($ip['responsavel'] ?? '-'); ?></td>
                                <td><span class="editable-field" ondblclick="editarDescricaoInline(<?php echo $ip['id']; ?>, this)"><?php echo htmlspecialchars($ip['descricao'] ?? '-'); ?></span></td>
                                <td class="ip-actions">
                                    <?php if ($ip['status'] == 'livre'): ?>
                                        <button onclick="abrirModalReservar(<?php echo $ip['id']; ?>, '<?php echo $ip['endereco']; ?>')" class="btn-sm btn-reservar">Reservar</button>
                                    <?php elseif ($ip['status'] == 'em_uso'): ?>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="ip_id" value="<?php echo $ip['id']; ?>">
                                            <input type="hidden" name="acao" value="liberar">
                                            <button type="submit" class="btn-sm btn-liberar" onclick="return confirm('Liberar este IP?')">Liberar</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php elseif ($subrede_id == 0 && count($subredes) > 0): ?>
            <div class="empty-state">Selecione uma sub-rede para visualizar os IPs.</div>
        <?php elseif (count($subredes) == 0): ?>
            <div class="empty-state">Nenhuma sub-rede cadastrada. <a href="../subredes/criar.php" class="btn-primary">Criar primeira sub-rede</a></div>
        <?php endif; ?>
    </div>

    <!-- Modal reservar IP -->
    <div id="modalReservar" class="modal">
        <div class="modal-content">
            <h3>Reservar IP</h3>
            <form method="POST" action="">
                <input type="hidden" name="ip_id" id="modal_ip_id">
                <input type="hidden" name="acao" value="reservar">
                <div class="form-group"><label>Endereço IP</label><input type="text" id="modal_ip_endereco" disabled style="background:#f5f5f5"></div>
                <div class="form-group"><label>Hostname</label><input type="text" id="hostname" name="hostname" placeholder="Ex: servidor-web-01"></div>
                <div class="form-group"><label>Responsável</label><input type="text" id="responsavel" name="responsavel" placeholder="Nome do responsável"></div>
                <div class="form-group"><label>Descrição</label><textarea id="descricao" name="descricao" rows="3"></textarea></div>
                <div class="modal-buttons"><button type="button" onclick="fecharModalReservar()" class="btn-secondary">Cancelar</button><button type="submit" class="btn-primary">Reservar</button></div>
            </form>
        </div>
    </div>

    <!-- Modal bulk create -->
    <div id="modalBulk" class="modal">
        <div class="modal-content">
            <h3>🚀 Ocupar IPs em Massa</h3>
            <p style="margin-bottom:1rem;">Crie vários IPs com nomeação automática!</p>
            <form method="POST" action="">
                <input type="hidden" name="bulk_create" value="1">
                <div class="form-group"><label>Quantidade:</label><input type="number" name="quantidade" id="bulk_quantidade" min="1" max="<?php echo $ips_livres_count; ?>" value="10" required><small style="color:var(--text-secondary);">Máximo: <?php echo $ips_livres_count; ?></small></div>
                <div class="form-group"><label>Nome base:</label><input type="text" name="base_nome" id="bulk_base_nome" placeholder="Ex: computador" required><small>Serão criados: base1, base2...</small></div>
                <div class="form-group"><label>Responsável:</label><input type="text" name="responsavel" id="bulk_responsavel" value="<?php echo htmlspecialchars($_SESSION["usuarioLogado"]); ?>"></div>
                <div class="form-group"><label>Descrição:</label><textarea name="descricao_bulk" rows="3"></textarea></div>
                <div class="modal-buttons"><button type="button" onclick="fecharModalBulk()" class="btn-secondary">Cancelar</button><button type="submit" class="btn-primary">Confirmar</button></div>
            </form>
        </div>
    </div>

<footer style="text-align: center; padding: 2rem; color: #888; margin-top: 2rem;">
    <p>IP Grid © 2026 - Gerenciamento de IPs</p>
    <p><a href="../termos.php" style="color: #667eea;">📜 Política de Privacidade e Termos de Uso</a></p>
</footer>

    <script>
        // Funções modais
        function abrirModalReservar(ipId, ipEndereco) {
            document.getElementById('modal_ip_id').value = ipId;
            document.getElementById('modal_ip_endereco').value = ipEndereco;
            document.getElementById('modalReservar').style.display = 'flex';
        }
        function fecharModalReservar() { document.getElementById('modalReservar').style.display = 'none'; }
        function abrirModalBulk() { document.getElementById('modalBulk').style.display = 'flex'; }
        function fecharModalBulk() { document.getElementById('modalBulk').style.display = 'none'; }

        // Fechar modais ao clicar fora
        window.onclick = function(e) {
            if(e.target == document.getElementById('modalReservar')) fecharModalReservar();
            if(e.target == document.getElementById('modalBulk')) fecharModalBulk();
        }

        // Edição inline hostname
        function editarHostnameInline(ipId, elemento) {
            const atual = elemento.textContent.trim();
            const td = elemento.parentElement;
            const input = document.createElement('input');
            input.type = 'text';
            input.value = atual === '-' ? '' : atual;
            input.className = 'editable-input';
            const savingSpan = document.createElement('span');
            savingSpan.className = 'editable-saving';
            savingSpan.textContent = ' ⏳';
            elemento.style.display = 'none';
            td.insertBefore(input, elemento);
            td.insertBefore(savingSpan, elemento.nextSibling);
            input.focus();
            input.addEventListener('keypress', (e) => { if(e.key === 'Enter') salvarHostname(ipId, input.value, elemento, input, savingSpan); });
            input.addEventListener('blur', () => {
                if(input.value !== (atual === '-' ? '' : atual)) salvarHostname(ipId, input.value, elemento, input, savingSpan);
                else { elemento.style.display = 'inline-block'; input.remove(); savingSpan.remove(); }
            });
            input.addEventListener('keydown', (e) => { if(e.key === 'Escape') { elemento.style.display = 'inline-block'; input.remove(); savingSpan.remove(); } });
        }
        function salvarHostname(ipId, novo, elemento, input, savingSpan) {
            savingSpan.style.display = 'inline';
            fetch('../api/ips.php', {
                method: 'PUT',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ id: ipId, hostname: novo || null })
            })
            .then(r => r.json())
            .then(data => {
                if(data.success) {
                    elemento.textContent = novo && novo.trim() !== '' ? novo : '-';
                    elemento.style.display = 'inline-block';
                    savingSpan.textContent = ' ✓';
                    setTimeout(() => savingSpan.remove(), 500);
                } else throw new Error();
            })
            .catch(() => { savingSpan.textContent = ' ❌'; setTimeout(() => savingSpan.remove(), 1000); })
            .finally(() => input.remove());
        }

        // Edição inline descrição
        function editarDescricaoInline(ipId, elemento) {
            const atual = elemento.textContent.trim();
            const td = elemento.parentElement;
            const input = document.createElement('input');
            input.type = 'text';
            input.value = atual === '-' ? '' : atual;
            input.className = 'editable-input';
            input.style.width = '200px';
            const savingSpan = document.createElement('span');
            savingSpan.className = 'editable-saving';
            savingSpan.textContent = ' ⏳';
            elemento.style.display = 'none';
            td.insertBefore(input, elemento);
            td.insertBefore(savingSpan, elemento.nextSibling);
            input.focus();
            input.addEventListener('keypress', (e) => { if(e.key === 'Enter') salvarDescricao(ipId, input.value, elemento, input, savingSpan); });
            input.addEventListener('blur', () => {
                if(input.value !== (atual === '-' ? '' : atual)) salvarDescricao(ipId, input.value, elemento, input, savingSpan);
                else { elemento.style.display = 'inline-block'; input.remove(); savingSpan.remove(); }
            });
            input.addEventListener('keydown', (e) => { if(e.key === 'Escape') { elemento.style.display = 'inline-block'; input.remove(); savingSpan.remove(); } });
        }
        function salvarDescricao(ipId, novo, elemento, input, savingSpan) {
            savingSpan.style.display = 'inline';
            fetch('../api/ips.php', {
                method: 'PUT',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ id: ipId, descricao: novo || null })
            })
            .then(r => r.json())
            .then(data => {
                if(data.success) {
                    elemento.textContent = novo && novo.trim() !== '' ? novo : '-';
                    elemento.style.display = 'inline-block';
                    savingSpan.textContent = ' ✓';
                    setTimeout(() => savingSpan.remove(), 500);
                } else throw new Error();
            })
            .catch(() => { savingSpan.textContent = ' ❌'; setTimeout(() => savingSpan.remove(), 1000); })
            .finally(() => input.remove());
        }

        // Dark mode toggle
        const darkModeToggle = document.getElementById('darkModeToggle');
        if(darkModeToggle) {
            const isDark = localStorage.getItem('darkMode') === 'true';
            if(isDark) { document.body.classList.add('dark'); darkModeToggle.textContent = '☀️'; }
            darkModeToggle.addEventListener('click', () => {
                document.body.classList.toggle('dark');
                const dark = document.body.classList.contains('dark');
                localStorage.setItem('darkMode', dark);
                darkModeToggle.textContent = dark ? '☀️' : '🌙';
            });
        }
    </script>
</body>
</html>