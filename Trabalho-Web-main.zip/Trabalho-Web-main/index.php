<?php
session_start();
$usuarioLogado = isset($_SESSION["usuarioLogado"]) ? $_SESSION["usuarioLogado"] : null;
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IP Grid - Gerenciamento Inteligente de IPs</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* ========== VARIÁVEIS DARK / LIGHT ========== */
        :root {
            --primary: #667eea;
            --secondary: #764ba2;
            --success: #22c55e;
            --bg-body-light: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --text-primary: #333;
            --text-secondary: #666;
            --card-bg: white;
            --navbar-bg: rgba(255, 255, 255, 0.95);
            --border-color: #eef2f7;
            --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --hover-bg: #f8f9fa;
            --footer-bg: #1a1a2e;
            --footer-text: white;
        }

        body.dark {
            --bg-body-light: #0f172a;
            --text-primary: #e2e8f0;
            --text-secondary: #94a3b8;
            --card-bg: #1e293b;
            --navbar-bg: #0f172a;
            --border-color: #334155;
            --shadow: 0 2px 10px rgba(0,0,0,0.2);
            --hover-bg: #334155;
            --footer-bg: #0f172a;
            --footer-text: #cbd5e1;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-body-light);
            color: var(--text-primary);
            line-height: 1.6;
            transition: background 0.3s, color 0.3s;
        }

        /* Navbar */
        .navbar {
            background: var(--navbar-bg);
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            transition: background 0.3s;
        }

        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1rem;
        }

        .logo {
            font-size: 1.5rem;
            font-weight: bold;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            white-space: nowrap;
        }

        .nav-links {
            display: flex;
            gap: 1.5rem;
            align-items: center;
            flex-wrap: wrap;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--text-secondary);
            font-weight: 500;
            transition: color 0.3s;
        }
        .nav-links a:hover {
            color: #667eea;
        }

        .user-name {
            color: #667eea;
            font-weight: bold;
            background: rgba(102, 126, 234, 0.1);
            padding: 0.4rem 1rem;
            border-radius: 20px;
            font-size: 0.9rem;
        }

        .btn-login, .btn-logout {
            padding: 0.6rem 1.5rem;
            border-radius: 25px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.95rem;
            transition: all 0.3s;
            display: inline-block;
        }
        .btn-login {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3);
        }
        .btn-login:hover {
            transform: translateY(-2px);
        }
        .btn-logout {
            background: #e74c3c;
            color: white;
        }
        .btn-logout:hover {
            background: #c0392b;
        }

        .dark-mode-btn {
            background: none;
            border: none;
            font-size: 1.3rem;
            cursor: pointer;
            color: #667eea;
            padding: 0.3rem 0.6rem;
            border-radius: 50%;
            transition: background 0.3s;
        }
        .dark-mode-btn:hover {
            background: rgba(0,0,0,0.1);
        }
        body.dark .dark-mode-btn:hover {
            background: rgba(255,255,255,0.1);
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 2rem;
        }

        .hero {
            padding: 120px 0 80px;
            text-align: center;
            color: white;
        }
        .hero h1 {
            font-size: 3rem;
            margin-bottom: 1rem;
            animation: fadeInUp 0.8s ease;
        }
        .hero p {
            font-size: 1.2rem;
            margin-bottom: 2rem;
            opacity: 0.9;
        }
        .hero-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }
        .btn-hero-primary {
            background: white;
            color: #667eea;
            padding: 1rem 2rem;
            border-radius: 50px;
            text-decoration: none;
            font-weight: bold;
            transition: transform 0.3s;
        }
        .btn-hero-primary:hover {
            transform: translateY(-2px);
        }
        .btn-hero-secondary {
            background: transparent;
            color: white;
            padding: 1rem 2rem;
            border-radius: 50px;
            text-decoration: none;
            font-weight: bold;
            border: 2px solid white;
        }

        .metrics {
            padding: 60px 0;
        }
        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            margin-top: -80px;
        }
        .metric-card {
            background: var(--card-bg);
            padding: 2rem;
            border-radius: 15px;
            text-align: center;
            box-shadow: var(--shadow);
            transition: transform 0.3s;
        }
        .metric-card:hover {
            transform: translateY(-5px);
        }
        .metric-number {
            font-size: 2.5rem;
            font-weight: bold;
            color: #667eea;
            margin: 1rem 0;
        }
        .metric-label {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }
        .progress-bar {
            width: 100%;
            height: 8px;
            background: var(--border-color);
            border-radius: 10px;
            overflow: hidden;
            margin: 1rem 0;
        }
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
            border-radius: 10px;
        }

        .features {
            padding: 80px 0;
            background: var(--card-bg);
        }
        .section-title {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 3rem;
            color: var(--text-primary);
        }
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
        }
        .feature-card {
            background: var(--card-bg);
            padding: 2rem;
            border-radius: 15px;
            text-align: center;
            box-shadow: var(--shadow);
            transition: transform 0.3s;
        }
        .feature-card:hover {
            transform: translateY(-5px);
        }
        .feature-icon {
            width: 80px;
            height: 80px;
            margin: 0 auto 1.5rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            color: white;
        }
        .feature-card h3 {
            margin-bottom: 1rem;
            color: var(--text-primary);
        }
        .feature-card p {
            color: var(--text-secondary);
        }

        .network-viz {
            padding: 80px 0;
            background: var(--card-bg);
        }
        .network-container {
            background: var(--hover-bg);
            border-radius: 15px;
            padding: 2rem;
            margin-top: 2rem;
        }
        .subnet-tree {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            gap: 2rem;
        }
        .subnet-node {
            background: var(--card-bg);
            padding: 1rem;
            border-radius: 10px;
            box-shadow: var(--shadow);
            min-width: 200px;
        }
        .subnet-name {
            font-weight: bold;
            color: #667eea;
            margin-bottom: 1rem;
            text-align: center;
        }
        .ip-list {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            justify-content: center;
        }
        .ip-block {
            width: 35px;
            height: 35px;
            border-radius: 5px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.7rem;
            font-weight: bold;
            cursor: pointer;
        }
        .ip-used { background: #4caf50; color: white; }
        .ip-free { background: #e0e0e0; color: #666; }
        .ip-warning { background: #ff9800; color: white; }

        .about {
            padding: 80px 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .about-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 3rem;
            align-items: center;
        }
        .tech-icons {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            margin-top: 1rem;
        }
        .tech-icon {
            background: rgba(255, 255, 255, 0.2);
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.9rem;
        }
        .team-members {
            display: flex;
            justify-content: space-between;
            gap: 1rem;
            margin-top: 1rem;
            flex-wrap: wrap;
        }
        .member {
            text-align: center;
            background: rgba(255, 255, 255, 0.1);
            padding: 1rem;
            border-radius: 12px;
            flex: 1;
            min-width: 100px;
        }
        .member-avatar {
            width: 60px;
            height: 60px;
            background: rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            margin: 0 auto 0.6rem;
        }
        .member-name {
            font-weight: bold;
            font-size: 0.9rem;
        }

        .footer {
            background: var(--footer-bg);
            color: var(--footer-text);
            padding: 3rem 0 1rem;
        }
        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            margin-bottom: 2rem;
        }
        .footer-section a {
            color: #ccc;
            text-decoration: none;
            display: block;
            margin-bottom: 0.5rem;
        }
        .footer-section a:hover {
            color: #667eea;
        }
        .footer-bottom {
            text-align: center;
            padding-top: 2rem;
            border-top: 1px solid rgba(255,255,255,0.1);
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 768px) {
            .nav-container { flex-direction: column; }
            .hero h1 { font-size: 2rem; }
            .about-content { grid-template-columns: 1fr; text-align: center; }
            .team-members { flex-wrap: wrap; }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">🌐 IP GRID</div>
            <div class="nav-links">
                <a href="#home">Início</a>
                <a href="#features">Funcionalidades</a>
                <a href="#network">Rede</a>
                <a href="#about">Sobre</a>
                <button id="darkModeToggle" class="dark-mode-btn">🌙</button>
                <span id="userDisplay" class="user-name"></span>
                <a id="loginLink" href="action/login.php" class="btn-login">Entrar</a>
                <button id="logoutBtn" class="btn-logout" style="display: none;">Sair</button>
            </div>
        </div>
    </nav>

    <section id="home" class="hero">
        <div class="container">
            <h1>Gerencie sua Rede com Inteligência</h1>
            <p>Centralize, organize e monitore toda a infraestrutura de IPs da sua organização em um só lugar.</p>
            <div class="hero-buttons">
                <?php if (isset($_SESSION["usuarioLogado"])): ?>
                    <a href="dashboard.php" class="btn-hero-primary">🚀 Acessar Dashboard</a>
                <?php else: ?>
                    <a href="action/login.php" class="btn-hero-primary">🔐 Fazer Login</a>
                <?php endif; ?>
                <a href="#network" class="btn-hero-secondary">📊 Ver Demonstração</a>
            </div>
        </div>
    </section>

    <section class="metrics">
        <div class="container">
            <div class="metrics-grid">
                <div class="metric-card"><div class="feature-icon" style="width:50px;height:50px;margin:0 auto 1rem;">📊</div><div class="metric-number">2,547</div><div class="metric-label">Total de IPs Gerenciados</div></div>
                <div class="metric-card"><div class="feature-icon" style="width:50px;height:50px;margin:0 auto 1rem;">✅</div><div class="metric-number">1,732</div><div class="metric-label">IPs em Uso</div><div class="progress-bar"><div class="progress-fill" style="width:68%"></div></div><div class="metric-label">68% de ocupação</div></div>
                <div class="metric-card"><div class="feature-icon" style="width:50px;height:50px;margin:0 auto 1rem;">🌐</div><div class="metric-number">24</div><div class="metric-label">Sub-redes Cadastradas</div></div>
                <div class="metric-card"><div class="feature-icon" style="width:50px;height:50px;margin:0 auto 1rem;">⚠️</div><div class="metric-number">3</div><div class="metric-label">Alertas Ativos</div></div>
            </div>
        </div>
    </section>

    <section id="features" class="features">
        <div class="container">
            <h2 class="section-title">Funcionalidades Principais</h2>
            <div class="features-grid">
                <div class="feature-card"><div class="feature-icon">🔍</div><h3>Descoberta de Rede</h3><p>Escaneie sua rede automaticamente e descubra dispositivos novos em tempo real.</p></div>
                <div class="feature-card"><div class="feature-icon">📝</div><h3>Reservas e DHCP</h3><p>Gerencie reservas de IP e integre-se com seu servidor DHCP facilmente.</p></div>
                <div class="feature-card"><div class="feature-icon">🌍</div><h3>DNS Integrado</h3><p>Associe IPs a nomes de domínio de forma intuitiva e organizada.</p></div>
                <div class="feature-card"><div class="feature-icon">🏗️</div><h3>Organização por Sub-redes</h3><p>Visualize suas sub-redes IPv4 e IPv6 de forma hierárquica e intuitiva.</p></div>
                <div class="feature-card"><div class="feature-icon">🔒</div><h3>Controle de Acesso</h3><p>Diferencie permissões de administradores, operadores e usuários.</p></div>
                <div class="feature-card"><div class="feature-icon">📈</div><h3>Relatórios</h3><p>Gere relatórios detalhados de auditoria e utilização da rede.</p></div>
            </div>
        </div>
    </section>

    <section id="network" class="network-viz">
        <div class="container">
            <h2 class="section-title">Visualização da Rede</h2>
            <p style="text-align:center;margin-bottom:2rem;">Mapa de calor das sub-redes - Ocupação em tempo real</p>
            <div class="network-container">
                <div class="subnet-tree">
                    <div class="subnet-node"><div class="subnet-name">10.0.1.0/24</div><div class="ip-list"><div class="ip-block ip-used">.1</div><div class="ip-block ip-used">.2</div><div class="ip-block ip-free">.3</div><div class="ip-block ip-used">.4</div><div class="ip-block ip-warning">.5</div><div class="ip-block ip-free">.6</div><div class="ip-block ip-used">.7</div><div class="ip-block ip-used">.8</div></div><div class="progress-bar"><div class="progress-fill" style="width:62%"></div></div></div>
                    <div class="subnet-node"><div class="subnet-name">10.0.2.0/24</div><div class="ip-list"><div class="ip-block ip-used">.1</div><div class="ip-block ip-used">.2</div><div class="ip-block ip-used">.3</div><div class="ip-block ip-used">.4</div><div class="ip-block ip-free">.5</div><div class="ip-block ip-free">.6</div><div class="ip-block ip-used">.7</div><div class="ip-block ip-free">.8</div></div><div class="progress-bar"><div class="progress-fill" style="width:50%"></div></div></div>
                    <div class="subnet-node"><div class="subnet-name">192.168.1.0/24</div><div class="ip-list"><div class="ip-block ip-used">.1</div><div class="ip-block ip-used">.2</div><div class="ip-block ip-used">.3</div><div class="ip-block ip-warning">.4</div><div class="ip-block ip-used">.5</div><div class="ip-block ip-used">.6</div><div class="ip-block ip-used">.7</div><div class="ip-block ip-free">.8</div></div><div class="progress-bar"><div class="progress-fill" style="width:87%"></div></div></div>
                </div>
                <p style="text-align:center;margin-top:2rem;">🟢 Em uso | ⚪ Disponível | 🟠 Próximo ao esgotamento</p>
            </div>
        </div>
    </section>

    <section id="about" class="about">
        <div class="container">
            <div class="about-content">
                <div>
                    <h2>Sobre o IP Grid</h2>
                    <p>Projeto desenvolvido para a disciplina de Prática Profissional em Programação Web com o objetivo de criar uma ferramenta eficiente para o gerenciamento de endereços IP.</p>
                    <p>Substitua planilhas por um sistema centralizado, evite conflitos e tenha visibilidade total da sua infraestrutura de rede.</p>
                    <div class="tech-icons"><span class="tech-icon">HTML5</span><span class="tech-icon">CSS3</span><span class="tech-icon">JavaScript</span><span class="tech-icon">React</span><span class="tech-icon">Node.js</span><span class="tech-icon">MySQL</span></div>
                </div>
                <div>
                    <h3>Equipe de Desenvolvimento</h3>
                    <div class="team-members">
                        <div class="member"><div class="member-avatar">👨‍💻</div><div class="member-name">Arthur Campos</div></div>
                        <div class="member"><div class="member-avatar">👨‍💻</div><div class="member-name">Gustavo Pereira</div></div>
                        <div class="member"><div class="member-avatar">👨‍💻</div><div class="member-name">Ian Luca</div></div>
                        <div class="member"><div class="member-avatar">👨‍💻</div><div class="member-name">Gabriel Wellington</div></div>
                        <div class="member"><div class="member-avatar">👨‍💻</div><div class="member-name">Gabriel Felipe</div></div>
                    </div>
                    <div style="margin-top:2rem;"><h3>Preparado para o Futuro</h3><p>✅ Suporte completo para IPv6</p><p>✅ Escalabilidade para redes empresariais</p><p>✅ API aberta para integrações</p></div>
                </div>
            </div>
        </div>
    </section>

<div class="footer">
    
</div>

    <footer class="footer">
    <div class="container">
        <div class="footer-content">
            <div class="footer-section"><h4>IP Grid</h4><p>Gerenciamento inteligente de endereços IP para sua infraestrutura de rede.</p></div>
            <div class="footer-section"><h4>Links Rápidos</h4><a href="#home">Início</a><a href="#features">Funcionalidades</a><a href="#network">Rede</a><a href="#about">Sobre</a></div>
            <div class="footer-section"><h4>Documentação</h4><a href="#">Manual do Usuário</a><a href="#">API Reference</a><a href="#">Guia de Instalação</a></div>
            <div class="footer-section"><h4>Contato</h4><a href="#">ipgrid@faculdade.edu.br</a><a href="#">GitHub do Projeto</a></div>
        </div>
        <div class="footer-bottom">
    <p>&copy; 2026 IP Grid - Trabalho Acadêmico de Prática Profissional em Programação Web</p>
    <p style="margin-top: 0.5rem;">
        <a href="termos.php" style="color: #ccc; text-decoration: none;">📜 Política de Privacidade e Termos de Uso</a>
    </p>
</div>
    </div>
</footer>

    <script>
        // Dark mode toggle
        const darkModeToggle = document.getElementById('darkModeToggle');
        if (darkModeToggle) {
            const isDark = localStorage.getItem('darkMode') === 'true';
            if (isDark) {
                document.body.classList.add('dark');
                darkModeToggle.textContent = '☀️';
            }
            darkModeToggle.addEventListener('click', () => {
                document.body.classList.toggle('dark');
                const isDarkNow = document.body.classList.contains('dark');
                localStorage.setItem('darkMode', isDarkNow);
                darkModeToggle.textContent = isDarkNow ? '☀️' : '🌙';
            });
        }

        // Login/logout dinâmico
        const usuarioLogado = <?php echo json_encode($usuarioLogado); ?>;
        const userDisplay = document.getElementById("userDisplay");
        const loginLink = document.getElementById("loginLink");
        const logoutBtn = document.getElementById("logoutBtn");

        if (usuarioLogado) {
            userDisplay.textContent = "👤 " + usuarioLogado;
            userDisplay.style.display = "inline-block";
            loginLink.style.display = "none";
            logoutBtn.style.display = "inline-block";
        } else {
            userDisplay.style.display = "none";
            loginLink.style.display = "inline-block";
            logoutBtn.style.display = "none";
        }

        logoutBtn?.addEventListener("click", () => { window.location.href = "action/logout.php"; });

        // Smooth scroll
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) target.scrollIntoView({ behavior: 'smooth' });
            });
        });
    </script>
</body>
</html>