<?php
require_once "includes/auth_check.php";
require_once "config/db.php";

// Estatísticas gerais
$totalSubredes = $pdo->query("SELECT COUNT(*) FROM subredes")->fetchColumn();
$totalIPs = $pdo->query("SELECT COUNT(*) FROM ips")->fetchColumn();
$totalEmUso = $pdo->query("SELECT COUNT(*) FROM ips WHERE status = 'em_uso'")->fetchColumn();
$totalLivres = $pdo->query("SELECT COUNT(*) FROM ips WHERE status = 'livre'")->fetchColumn();
$totalReservados = $pdo->query("SELECT COUNT(*) FROM ips WHERE status = 'reservado'")->fetchColumn();
$totalExpirados = $pdo->query("SELECT COUNT(*) FROM ips WHERE status = 'expirado'")->fetchColumn();

$ocupacao = ($totalIPs > 0) ? round(($totalEmUso / $totalIPs) * 100) : 0;

// Buscar todas as sub-redes com estatísticas
$subredes = $pdo->query("
    SELECT 
        s.id,
        s.nome,
        s.rede,
        s.mascara,
        s.descricao,
        COUNT(i.id) AS total_ips,
        SUM(CASE WHEN i.status = 'em_uso' THEN 1 ELSE 0 END) AS em_uso,
        SUM(CASE WHEN i.status = 'livre' THEN 1 ELSE 0 END) AS livres,
        SUM(CASE WHEN i.status = 'reservado' THEN 1 ELSE 0 END) AS reservados,
        SUM(CASE WHEN i.status = 'expirado' THEN 1 ELSE 0 END) AS expirados
    FROM subredes s
    LEFT JOIN ips i ON s.id = i.subrede_id
    GROUP BY s.id, s.nome, s.rede, s.mascara, s.descricao
")->fetchAll(PDO::FETCH_ASSOC);

// Tratar valores e classificar cada sub-rede
foreach ($subredes as &$sub) {
    $sub['total_ips'] = (int)($sub['total_ips'] ?? 0);
    $sub['em_uso'] = (int)($sub['em_uso'] ?? 0);
    $sub['livres'] = (int)($sub['livres'] ?? 0);
    $sub['reservados'] = (int)($sub['reservados'] ?? 0);
    $sub['expirados'] = (int)($sub['expirados'] ?? 0);

    $sub['percentual'] = ($sub['total_ips'] > 0)
        ? round(($sub['em_uso'] / $sub['total_ips']) * 100)
        : 0;

    if ($sub['percentual'] <= 30) {
        $sub['status_label'] = 'Ótimo';
        $sub['status_class'] = 'otimo';
        $sub['emoji'] = '🟢';
    } elseif ($sub['percentual'] <= 60) {
        $sub['status_label'] = 'Normal';
        $sub['status_class'] = 'normal';
        $sub['emoji'] = '🟡';
    } elseif ($sub['percentual'] <= 85) {
        $sub['status_label'] = 'Atenção';
        $sub['status_class'] = 'atencao';
        $sub['emoji'] = '🟠';
    } else {
        $sub['status_label'] = 'Crítico';
        $sub['status_class'] = 'critico';
        $sub['emoji'] = '🔴';
    }
}
unset($sub);

// Ranking por ocupação
$rankingSubredes = $subredes;
usort($rankingSubredes, function ($a, $b) {
    return $b['percentual'] <=> $a['percentual'];
});

// Alertas (80% ou mais)
$alertas = array_filter($rankingSubredes, function ($sub) {
    return $sub['percentual'] >= 80;
});

// Últimas sub-redes
$ultimasSubredes = array_slice($rankingSubredes, 0, 5);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - IP Grid IPAM</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* ========== VARIÁVEIS DARK / LIGHT ========== */
        :root {
            --primary: #667eea;
            --secondary: #764ba2;
            --success: #22c55e;
            --warning: #eab308;
            --attention: #f97316;
            --danger: #ef4444;
            --bg-body: #f5f7fb;
            --text-primary: #333;
            --text-secondary: #666;
            --card-bg: white;
            --navbar-bg: white;
            --border-color: #eef2f7;
            --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --table-header-bg: #f8f9fa;
            --table-border: #dee2e6;
            --hover-bg: #f8f9fa;
            --input-bg: white;
            --input-border: #ddd;
            --heatmap-bg: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
        }

        body.dark {
            --bg-body: #0f172a;
            --text-primary: #e2e8f0;
            --text-secondary: #94a3b8;
            --card-bg: #1e293b;
            --navbar-bg: #0f172a;
            --border-color: #334155;
            --shadow: 0 2px 10px rgba(0,0,0,0.2);
            --table-header-bg: #334155;
            --table-border: #475569;
            --hover-bg: #334155;
            --input-bg: #1e293b;
            --input-border: #475569;
            --heatmap-bg: #0f172a;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-body);
            color: var(--text-primary);
            transition: background 0.3s, color 0.3s;
        }

        /* Navbar */
        .navbar {
            background: var(--navbar-bg);
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            transition: background 0.3s;
        }

        .nav-container {
            max-width: 1280px;
            margin: 0 auto;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 1rem;
        }

        .logo {
            font-size: 1.5rem;
            font-weight: bold;
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            white-space: nowrap;
        }

        .nav-links {
            display: flex;
            gap: 1.25rem;
            align-items: center;
            flex-wrap: wrap;
        }

        .nav-links a {
            text-decoration: none;
            color: var(--text-secondary);
            font-weight: 500;
            transition: color 0.3s;
        }
        .nav-links a:hover {
            color: var(--primary);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-name {
            color: var(--primary);
            font-weight: bold;
        }

        .btn-logout {
            background: #e74c3c;
            color: white;
            padding: 0.5rem 1.2rem;
            border-radius: 25px;
            text-decoration: none;
            font-size: 0.9rem;
            transition: all 0.3s;
        }
        .btn-logout:hover {
            background: #c0392b;
        }

        .dark-mode-btn {
            background: none;
            border: none;
            font-size: 1.3rem;
            cursor: pointer;
            color: var(--primary);
            padding: 0.3rem 0.6rem;
            border-radius: 50%;
            transition: background 0.3s;
        }
        .dark-mode-btn:hover {
            background: rgba(0,0,0,0.1);
        }
        body.dark .dark-mode-btn:hover {
            background: rgba(255,255,255,0.1);
        }

        .container {
            max-width: 1280px;
            margin: 0 auto;
            padding: 2rem;
            margin-top: 86px;
        }

        .page-header {
            margin-bottom: 2rem;
        }
        .page-header h1 {
            color: var(--text-primary);
            font-size: 2rem;
        }
        .page-header p {
            color: var(--text-secondary);
            margin-top: 0.5rem;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.25rem;
            margin-bottom: 2rem;
        }
        .stat-card {
            background: var(--card-bg);
            padding: 1.5rem;
            border-radius: 16px;
            box-shadow: var(--shadow);
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-4px);
        }
        .stat-card h3 {
            color: var(--text-secondary);
            font-size: 0.9rem;
            margin-bottom: 0.5rem;
        }
        .stat-number {
            font-size: 2.2rem;
            font-weight: bold;
            color: var(--primary);
            margin-bottom: 0.4rem;
        }
        .stat-label {
            color: var(--text-secondary);
            font-size: 0.85rem;
        }
        .progress-bar {
            width: 100%;
            height: 8px;
            background: var(--border-color);
            border-radius: 999px;
            overflow: hidden;
            margin-top: 0.65rem;
        }
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--primary) 0%, var(--secondary) 100%);
            border-radius: 999px;
        }

        .section {
            background: var(--card-bg);
            border-radius: 18px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow);
        }
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.25rem;
            padding-bottom: 0.75rem;
            border-bottom: 1px solid var(--border-color);
            flex-wrap: wrap;
            gap: 1rem;
        }
        .section-header h2 {
            color: var(--text-primary);
            font-size: 1.25rem;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 0.7rem 1.2rem;
            border-radius: 10px;
            text-decoration: none;
            font-size: 0.92rem;
            transition: transform 0.3s;
            display: inline-block;
            border: none;
            cursor: pointer;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
            padding: 0.45rem 1rem;
            border-radius: 8px;
            text-decoration: none;
            font-size: 0.84rem;
        }

        /* Heatmap */
        .heatmap-shell {
            background: var(--heatmap-bg);
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: 22px;
            padding: 1.5rem;
            color: white;
        }
        .heatmap-title h3 {
            font-size: 1.4rem;
            margin-bottom: 0.25rem;
        }
        .heatmap-title p {
            color: #cbd5e1;
            font-size: 0.95rem;
        }
        .legend {
            display: flex;
            gap: 1rem;
            align-items: center;
            flex-wrap: wrap;
            background: rgba(255,255,255,0.04);
            border: 1px solid rgba(255,255,255,0.06);
            border-radius: 999px;
            padding: 0.75rem 1rem;
            margin-bottom: 1.25rem;
        }
        .legend-title {
            color: #94a3b8;
            font-size: 0.78rem;
            text-transform: uppercase;
            font-weight: 700;
        }
        .legend-item {
            display: flex;
            align-items: center;
            gap: 0.45rem;
            color: #e2e8f0;
            font-size: 0.88rem;
        }
        .legend-color {
            width: 16px;
            height: 16px;
            border-radius: 5px;
        }
        .heatmap-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        .heat-card {
            padding: 1rem;
            border-radius: 18px;
            color: white;
            transition: transform 0.25s;
        }
        .heat-card:hover {
            transform: translateY(-5px);
        }
        .heat-card.otimo { background: linear-gradient(135deg, #16a34a, #22c55e); }
        .heat-card.normal { background: linear-gradient(135deg, #ca8a04, #eab308); }
        .heat-card.atencao { background: linear-gradient(135deg, #ea580c, #f97316); }
        .heat-card.critico { background: linear-gradient(135deg, #dc2626, #ef4444); }
        .heat-card-name {
            font-size: 1rem;
            font-weight: 700;
        }
        .heat-card-network {
            font-size: 0.84rem;
            opacity: 0.9;
        }
        .heat-card-percent {
            font-size: 2rem;
            font-weight: 800;
            margin-top: 0.5rem;
        }
        .heat-mini-bar {
            width: 100%;
            height: 8px;
            background: rgba(255,255,255,0.25);
            border-radius: 999px;
            margin-top: 0.5rem;
        }
        .heat-mini-bar-fill {
            height: 100%;
            background: rgba(255,255,255,0.95);
            border-radius: 999px;
        }
        .heat-card-footer {
            display: flex;
            justify-content: space-between;
            margin-top: 0.6rem;
            font-size: 0.85rem;
        }
        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            padding: 0.35rem 0.7rem;
            border-radius: 999px;
            font-size: 0.75rem;
            font-weight: 700;
            background: rgba(255,255,255,0.2);
        }
        .ranking-box {
            margin-top: 1rem;
            border: 1px solid rgba(255,255,255,0.08);
            border-radius: 18px;
            overflow: hidden;
        }
        .ranking-title {
            padding: 1rem 1.1rem;
            font-weight: 700;
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }
        .ranking-row {
            display: grid;
            grid-template-columns: 50px 1.5fr 1.2fr 1fr 70px 100px;
            gap: 1rem;
            align-items: center;
            padding: 0.9rem 1.1rem;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            color: #e2e8f0;
        }
        .ranking-row:last-child { border-bottom: none; }
        .ranking-pos { color: #94a3b8; font-weight: 600; }
        .ranking-name { font-weight: 600; }
        .ranking-net { color: #cbd5e1; font-size: 0.88rem; }
        .ranking-bar {
            width: 100%;
            height: 9px;
            background: rgba(148,163,184,0.25);
            border-radius: 999px;
            overflow: hidden;
        }
        .ranking-bar-fill { height: 100%; border-radius: 999px; }
        .ranking-bar-fill.otimo { background: var(--success); }
        .ranking-bar-fill.normal { background: var(--warning); }
        .ranking-bar-fill.atencao { background: var(--attention); }
        .ranking-bar-fill.critico { background: var(--danger); }
        .ranking-percent { font-weight: 800; text-align: right; }
        .ranking-percent.otimo { color: var(--success); }
        .ranking-percent.normal { color: var(--warning); }
        .ranking-percent.atencao { color: var(--attention); }
        .ranking-percent.critico { color: var(--danger); }
        .ranking-status { justify-self: end; }
        .ranking-status.otimo { color: var(--success); }
        .ranking-status.normal { color: var(--warning); }
        .ranking-status.atencao { color: var(--attention); }
        .ranking-status.critico { color: var(--danger); }

        .subnet-list { display: grid; gap: 1rem; }
        .subnet-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem;
            background: var(--hover-bg);
            border-radius: 12px;
            gap: 1rem;
            flex-wrap: wrap;
        }
        .subnet-info h4 { color: var(--text-primary); margin-bottom: 0.3rem; }
        .subnet-info p { color: var(--text-secondary); font-size: 0.88rem; }
        .subnet-stats { text-align: right; }
        .subnet-stats .percent { font-weight: bold; color: var(--primary); font-size: 1rem; }
        .subnet-status {
            display: inline-block;
            margin-top: 0.4rem;
            padding: 0.28rem 0.55rem;
            border-radius: 999px;
            font-size: 0.76rem;
            font-weight: 700;
        }
        .subnet-status.otimo { background: rgba(34,197,94,0.12); color: #15803d; }
        .subnet-status.normal { background: rgba(234,179,8,0.14); color: #a16207; }
        .subnet-status.atencao { background: rgba(249,115,22,0.14); color: #c2410c; }
        .subnet-status.critico { background: rgba(239,68,68,0.14); color: #b91c1c; }
        body.dark .subnet-status.otimo { background: rgba(34,197,94,0.2); color: #4ade80; }
        body.dark .subnet-status.normal { background: rgba(234,179,8,0.2); color: #fde047; }
        body.dark .subnet-status.atencao { background: rgba(249,115,22,0.2); color: #fdba74; }
        body.dark .subnet-status.critico { background: rgba(239,68,68,0.2); color: #fca5a5; }

        .alert-list { display: grid; gap: 0.8rem; }
        .alert-item {
            padding: 1rem;
            background: #fff7ed;
            border-left: 4px solid #f97316;
            border-radius: 10px;
        }
        body.dark .alert-item {
            background: #331a0d;
            border-left-color: #f97316;
        }
        .alert-item h4 { color: #c2410c; margin-bottom: 0.3rem; }
        body.dark .alert-item h4 { color: #fdba74; }
        .alert-item p { color: var(--text-secondary); font-size: 0.92rem; }

        .empty-state { text-align: center; padding: 3rem; color: var(--text-secondary); }
        .footer {
            text-align: center;
            padding: 2rem;
            color: var(--text-secondary);
            margin-top: 1rem;
            border-top: 1px solid var(--border-color);
        }
        .footer a {
            color: var(--primary);
            text-decoration: none;
        }
        .footer a:hover {
            text-decoration: underline;
        }

        @media (max-width: 900px) {
            .nav-container { flex-direction: column; }
            .ranking-row { grid-template-columns: 1fr; gap: 0.55rem; align-items: start; }
            .ranking-status { justify-self: start; }
            .ranking-percent { text-align: left; }
            .subnet-stats { text-align: left; width: 100%; }
        }
        @media (max-width: 600px) {
            .container { padding: 1rem; margin-top: 90px; }
            .heatmap-cards { grid-template-columns: 1fr; }
            .legend { border-radius: 16px; }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">🌐 IP GRID IPAM</div>
            <div class="nav-links">
                <a href="dashboard.php">Dashboard</a>
                <a href="subredes/index.php">Sub-redes</a>
                <a href="ips/index.php">IPs</a>
                <a href="index.php">Site</a>
                <button id="darkModeToggle" class="dark-mode-btn">🌙</button>
                <div class="user-info">
                    <span class="user-name">👤 <?php echo htmlspecialchars($usuarioLogado); ?></span>
                    <a href="action/logout.php" class="btn-logout">Sair</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="page-header">
            <h1>Dashboard</h1>
            <p>Bem-vindo ao sistema de gerenciamento IPAM. Visualize o status da sua rede e a ocupação das sub-redes.</p>
        </div>

        <!-- Cards de estatísticas -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total de Sub-redes</h3>
                <div class="stat-number"><?php echo $totalSubredes; ?></div>
                <div class="stat-label">Redes cadastradas</div>
            </div>
            <div class="stat-card">
                <h3>Total de IPs</h3>
                <div class="stat-number"><?php echo $totalIPs; ?></div>
                <div class="stat-label">Endereços gerenciados</div>
            </div>
            <div class="stat-card">
                <h3>IPs em Uso</h3>
                <div class="stat-number"><?php echo $totalEmUso; ?></div>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: <?php echo $ocupacao; ?>%"></div>
                </div>
                <div class="stat-label"><?php echo $ocupacao; ?>% de ocupação</div>
            </div>
            <div class="stat-card">
                <h3>IPs Livres</h3>
                <div class="stat-number"><?php echo $totalLivres; ?></div>
                <div class="stat-label">Disponíveis para uso</div>
            </div>
            <div class="stat-card">
                <h3>Reservados</h3>
                <div class="stat-number"><?php echo $totalReservados; ?></div>
                <div class="stat-label">IPs reservados</div>
            </div>
            <div class="stat-card">
                <h3>Expirados</h3>
                <div class="stat-number"><?php echo $totalExpirados; ?></div>
                <div class="stat-label">Necessitam revisão</div>
            </div>
        </div>

        <!-- Mapa de Calor -->
        <div class="section">
            <div class="section-header">
                <div>
                    <h2>🌡️ Mapa de Calor por Sub-rede</h2>
                    <p>As sub-redes são exibidas dinamicamente conforme o cadastro do usuário.</p>
                </div>
            </div>
            <div class="heatmap-shell">
                <div class="heatmap-topbar">
                    <div class="heatmap-title">
                        <h3>Mapa de Calor</h3>
                        <p>Visualize o uso de IPs por sub-rede em tempo real</p>
                    </div>
                </div>
                <div class="legend">
                    <span class="legend-title">Legenda:</span>
                    <div class="legend-item"><span class="legend-color" style="background:#22c55e;"></span> Ótimo (0–30%)</div>
                    <div class="legend-item"><span class="legend-color" style="background:#eab308;"></span> Normal (31–60%)</div>
                    <div class="legend-item"><span class="legend-color" style="background:#f97316;"></span> Atenção (61–85%)</div>
                    <div class="legend-item"><span class="legend-color" style="background:#ef4444;"></span> Crítico (86–100%)</div>
                </div>
                <?php if (count($rankingSubredes) > 0): ?>
                    <div class="heatmap-cards">
                        <?php foreach ($rankingSubredes as $sub): ?>
                            <div class="heat-card <?php echo $sub['status_class']; ?>"
                                 title="<?php echo htmlspecialchars($sub['nome']) . ' - ' . $sub['rede'] . '/' . $sub['mascara'] . ' | Em uso: ' . $sub['em_uso'] . '/' . $sub['total_ips']; ?>">
                                <div class="heat-card-top">
                                    <div>
                                        <div class="heat-card-name"><?php echo htmlspecialchars($sub['nome']); ?></div>
                                        <div class="heat-card-network"><?php echo htmlspecialchars($sub['rede']); ?>/<?php echo htmlspecialchars($sub['mascara']); ?></div>
                                    </div>
                                    <div class="status-badge"><?php echo $sub['emoji']; ?> <?php echo $sub['status_label']; ?></div>
                                </div>
                                <div class="heat-card-bottom">
                                    <div class="heat-card-percent"><?php echo $sub['percentual']; ?>%</div>
                                    <div class="heat-mini-bar">
                                        <div class="heat-mini-bar-fill" style="width: <?php echo $sub['percentual']; ?>%"></div>
                                    </div>
                                    <div class="heat-card-footer">
                                        <span><?php echo $sub['em_uso']; ?>/<?php echo $sub['total_ips']; ?> IPs em uso</span>
                                        <span>Livres: <?php echo $sub['livres']; ?></span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="ranking-box">
                        <div class="ranking-title">📊 Ranking de Uso por Sub-rede</div>
                        <?php foreach ($rankingSubredes as $index => $sub): ?>
                            <div class="ranking-row">
                                <div class="ranking-pos">#<?php echo $index + 1; ?></div>
                                <div class="ranking-name"><?php echo htmlspecialchars($sub['nome']); ?></div>
                                <div class="ranking-net"><?php echo htmlspecialchars($sub['rede']); ?>/<?php echo htmlspecialchars($sub['mascara']); ?></div>
                                <div class="ranking-bar">
                                    <div class="ranking-bar-fill <?php echo $sub['status_class']; ?>" style="width: <?php echo $sub['percentual']; ?>%"></div>
                                </div>
                                <div class="ranking-percent <?php echo $sub['status_class']; ?>"><?php echo $sub['percentual']; ?>%</div>
                                <div class="ranking-status <?php echo $sub['status_class']; ?>"><?php echo $sub['status_label']; ?></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <p>Nenhuma sub-rede cadastrada ainda.</p>
                        <a href="subredes/criar.php" class="btn-primary">Cadastrar primeira sub-rede</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Últimas sub-redes -->
        <div class="section">
            <div class="section-header">
                <h2>📡 Sub-redes Cadastradas</h2>
                <a href="subredes/criar.php" class="btn-primary">+ Nova Sub-rede</a>
            </div>
            <div class="subnet-list">
                <?php if (count($ultimasSubredes) > 0): ?>
                    <?php foreach ($ultimasSubredes as $sub): ?>
                        <div class="subnet-item">
                            <div class="subnet-info">
                                <h4><?php echo htmlspecialchars($sub['nome']); ?></h4>
                                <p><?php echo htmlspecialchars($sub['rede']); ?>/<?php echo htmlspecialchars($sub['mascara']); ?></p>
                                <?php if (!empty($sub['descricao'])): ?>
                                    <p><?php echo htmlspecialchars($sub['descricao']); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="subnet-stats">
                                <div class="percent"><?php echo $sub['percentual']; ?>%</div>
                                <div class="stat-label"><?php echo $sub['em_uso']; ?>/<?php echo $sub['total_ips']; ?> IPs em uso</div>
                                <span class="subnet-status <?php echo $sub['status_class']; ?>"><?php echo $sub['status_label']; ?></span>
                                <br>
                                <a href="ips/index.php?subrede=<?php echo $sub['id']; ?>" class="btn-secondary" style="margin-top: 0.6rem;">Ver IPs</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <p>Nenhuma sub-rede cadastrada ainda.</p>
                        <a href="subredes/criar.php" class="btn-primary">Criar primeira sub-rede</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Alertas -->
        <div class="section">
            <div class="section-header">
                <h2>⚠️ Alertas de Ocupação</h2>
            </div>
            <div class="alert-list">
                <?php if (count($alertas) > 0): ?>
                    <?php foreach ($alertas as $alerta): ?>
                        <div class="alert-item">
                            <h4><?php echo htmlspecialchars($alerta['nome']); ?></h4>
                            <p>A sub-rede <strong><?php echo htmlspecialchars($alerta['rede']); ?>/<?php echo htmlspecialchars($alerta['mascara']); ?></strong> está com <strong><?php echo $alerta['percentual']; ?>%</strong> de ocupação (<?php echo $alerta['em_uso']; ?>/<?php echo $alerta['total_ips']; ?> IPs em uso).</p>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <p>✅ Nenhuma sub-rede em estado crítico no momento.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="footer">
            <p>IP Grid © 2026 - Sistema de Gerenciamento Inteligente de IPs</p>
            <p><a href="termos.php">📜 Termos de Uso</a> | <a href="privacidade.php">🔒 Política de Privacidade</a></p>
        </div>
    </div>

    <script>
        // Dark mode toggle
        const darkModeToggle = document.getElementById('darkModeToggle');
        if (darkModeToggle) {
            const isDark = localStorage.getItem('darkMode') === 'true';
            if (isDark) {
                document.body.classList.add('dark');
                darkModeToggle.textContent = '☀️';
            }
            darkModeToggle.addEventListener('click', () => {
                document.body.classList.toggle('dark');
                const isDarkNow = document.body.classList.contains('dark');
                localStorage.setItem('darkMode', isDarkNow);
                darkModeToggle.textContent = isDarkNow ? '☀️' : '🌙';
            });
        }
    </script>
</body>
</html>